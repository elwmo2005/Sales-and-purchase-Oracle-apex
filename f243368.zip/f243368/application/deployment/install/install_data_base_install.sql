prompt --application/deployment/install/install_data_base_install
begin
--   Manifest
--     INSTALL: INSTALL-data_base_install
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(39380193110247259161)
,p_install_id=>wwv_flow_imp.id(39380192521912247762)
,p_name=>'data_base_install'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'  CREATE TABLE "BANK" ',
'   (	"BANK_C" NUMBER(3,0), ',
'	"BANK_N" VARCHAR2(100), ',
'	"BANK_ADD" VARCHAR2(150), ',
'	"BRANCH" VARCHAR2(100)',
'   ) ;',
'',
'  CREATE TABLE "BOX" ',
'   (	"BOX_SEQ" NUMBER(6,0), ',
'	"AMOUNT_V" NUMBER(11,2), ',
'	"DEALER_C" NUMBER(11,2), ',
'	"DOC_NO" NUMBER(6,0), ',
'	"NOTE" VARCHAR2(100), ',
'	"TRANS_C" NUMBER(1,0), ',
'	"UP_DATE" DATE, ',
'	"COMP_C" NUMBER(2,0), ',
'	"USER_C" NUMBER(2,0), ',
'	"BOX_DATE" DATE, ',
'	"DEALER_TYPE" NUMBER(9,0), ',
'	"BOX_TYPE" NUMBER(1,0), ',
'	"PAY_TYPE" NUMBER(1,0), ',
'	"BANK_C" NUMBER(3,0), ',
'	"CHECK_NO" NUMBER(20,0), ',
'	"EMP_ID" NUMBER(3,0), ',
'	"TRANS_SEQ" NUMBER(7,0), ',
'	"CHECK_DATE" DATE, ',
'	 CONSTRAINT "BOX_CON" PRIMARY KEY ("BOX_SEQ")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "BOX_OLD" ',
'   (	"BOX_SEQ" NUMBER(6,0), ',
'	"AMOUNT_V" NUMBER(11,2), ',
'	"DEALER_C" NUMBER(11,2), ',
'	"DOC_NO" NUMBER(6,0), ',
'	"NOTE" VARCHAR2(100), ',
'	"TRANS_C" NUMBER(1,0), ',
'	"UP_DATE" DATE, ',
'	"COMP_C" VARCHAR2(2), ',
'	"USER_C" VARCHAR2(2), ',
'	"BOX_DATE" DATE, ',
'	"DEALER_TYPE" NUMBER(9,0), ',
'	"BOX_TYPE" NUMBER(1,0), ',
'	"PAY_TYPE" NUMBER(1,0), ',
'	"BANK_C" NUMBER(3,0), ',
'	"CHECK_NO" NUMBER(20,0), ',
'	"EMP_ID" NUMBER(3,0), ',
'	"TRANS_SEQ" NUMBER(7,0), ',
'	"CHECK_DATE" DATE, ',
'	 CONSTRAINT "BOX_BOX_C_PK" PRIMARY KEY ("BOX_SEQ") DISABLE',
'   ) ;',
'',
'  CREATE TABLE "CHECK_TYPE" ',
'   (	"CHCK_C" NUMBER(1,0), ',
'	"CHCK_N" VARCHAR2(30)',
'   ) ;',
'',
'  CREATE TABLE "CLASS" ',
'   (	"CLASS_C" NUMBER, ',
'	"CLASS_N" VARCHAR2(300), ',
'	"CLASS_DESC" VARCHAR2(300), ',
'	 CONSTRAINT "CLASS_PK" PRIMARY KEY ("CLASS_C")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "COMPANY" ',
'   (	"COMP_C" NUMBER(2,0) NOT NULL ENABLE, ',
'	"COMP_N" VARCHAR2(100) NOT NULL ENABLE, ',
'	"ADDRESS" VARCHAR2(100), ',
'	"TEL1" VARCHAR2(15), ',
'	"TEL2" VARCHAR2(15), ',
'	"FAX" VARCHAR2(15), ',
'	"MOBILE" VARCHAR2(15), ',
'	"UP_DATE" DATE, ',
'	"USER_ID" NUMBER(2,0), ',
'	"NOTE" VARCHAR2(200), ',
'	 CONSTRAINT "COMPANY_COMP_C_PK" PRIMARY KEY ("COMP_C")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "DEALERS" ',
'   (	"DEALER_C" NUMBER NOT NULL ENABLE, ',
'	"DEALER_N" VARCHAR2(100), ',
'	"ADDRESS" VARCHAR2(100), ',
'	"PHONE" VARCHAR2(15), ',
'	"MOBILE" VARCHAR2(15), ',
'	"DEALER_TYPE" NUMBER(1,0), ',
'	"CONTACT_C" NUMBER(2,0), ',
'	"COMP_C" VARCHAR2(2), ',
'	"USER_C" VARCHAR2(2), ',
'	"SALES" NUMBER(11,2), ',
'	"SALES_RETURN" NUMBER(11,2), ',
'	"BUY" NUMBER(11,2), ',
'	"BUY_RETURN" NUMBER(11,2), ',
'	"DEALER_CREDIT" NUMBER(11,2), ',
'	"DEALER_CREDIT_BACK" NUMBER(11,2), ',
'	"CASH_IN" NUMBER(11,2), ',
'	"CASH_OUT" NUMBER(11,2), ',
'	"DIS_VAL" NUMBER(11,2), ',
'	"OPEN_BAL" NUMBER(11,2), ',
'	"BALANCE" NUMBER(11,2), ',
'	"UP_DATE" DATE, ',
'	 CONSTRAINT "DEALERS_PK" PRIMARY KEY ("DEALER_C")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "DEPT" ',
'   (	"DEPTNO" NUMBER(2,0), ',
'	"DNAME" VARCHAR2(14), ',
'	"LOC" VARCHAR2(13), ',
'	 PRIMARY KEY ("DEPTNO")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "DOC_TYPE" ',
'   (	"DOC_C" NUMBER(1,0), ',
'	"DOC_N" VARCHAR2(50)',
'   ) ;',
'',
'  CREATE TABLE "EMPLOYEE" ',
'   (	"EMP_ID" NUMBER(3,0), ',
'	"EMP_N" CHAR(50), ',
'	"ADDRESS" VARCHAR2(100), ',
'	"PHONE" VARCHAR2(15), ',
'	"MOBILE" VARCHAR2(15), ',
'	"USER_C" NUMBER(3,0), ',
'	"UP_DATE" DATE, ',
'	"JOB" VARCHAR2(100), ',
'	"DEPT_C" NUMBER(3,0), ',
'	"COMP_C" NUMBER(2,0), ',
'	 CONSTRAINT "EMPLOYEE_CON" PRIMARY KEY ("EMP_ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "FACTORY" ',
'   (	"FACTOR_C" NUMBER(2,0), ',
'	"FACTOR_N" VARCHAR2(100), ',
'	 CONSTRAINT "FACTORY_FACTOR_C_PK" PRIMARY KEY ("FACTOR_C")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "HTMLDB_PLAN_TABLE" ',
'   (	"STATEMENT_ID" VARCHAR2(30), ',
'	"PLAN_ID" NUMBER, ',
'	"TIMESTAMP" DATE, ',
'	"REMARKS" VARCHAR2(4000), ',
'	"OPERATION" VARCHAR2(30), ',
'	"OPTIONS" VARCHAR2(255), ',
'	"OBJECT_NODE" VARCHAR2(128), ',
'	"OBJECT_OWNER" VARCHAR2(128), ',
'	"OBJECT_NAME" VARCHAR2(128), ',
'	"OBJECT_ALIAS" VARCHAR2(261), ',
'	"OBJECT_INSTANCE" NUMBER(*,0), ',
'	"OBJECT_TYPE" VARCHAR2(128), ',
'	"OPTIMIZER" VARCHAR2(255), ',
'	"SEARCH_COLUMNS" NUMBER, ',
'	"ID" NUMBER(*,0), ',
'	"PARENT_ID" NUMBER(*,0), ',
'	"DEPTH" NUMBER(*,0), ',
'	"POSITION" NUMBER(*,0), ',
'	"COST" NUMBER(*,0), ',
'	"CARDINALITY" NUMBER(*,0), ',
'	"BYTES" NUMBER(*,0), ',
'	"OTHER_TAG" VARCHAR2(255), ',
'	"PARTITION_START" VARCHAR2(255), ',
'	"PARTITION_STOP" VARCHAR2(255), ',
'	"PARTITION_ID" NUMBER(*,0), ',
'	"OTHER" LONG, ',
'	"DISTRIBUTION" VARCHAR2(30), ',
'	"CPU_COST" NUMBER(*,0), ',
'	"IO_COST" NUMBER(*,0), ',
'	"TEMP_SPACE" NUMBER(*,0), ',
'	"ACCESS_PREDICATES" VARCHAR2(4000), ',
'	"FILTER_PREDICATES" VARCHAR2(4000), ',
'	"PROJECTION" VARCHAR2(4000), ',
'	"TIME" NUMBER(*,0), ',
'	"QBLOCK_NAME" VARCHAR2(128)',
'   ) ;',
'',
'  CREATE TABLE "INVOICE" ',
'   (	"INV_NO" NUMBER(11,0), ',
'	"INV_DATE" DATE, ',
'	"INV_TYPE" NUMBER(1,0), ',
'	"STORE_NO" NUMBER(1,0), ',
'	"DEALER_C" NUMBER(3,0), ',
'	"DEALER_TYPE" NUMBER(1,0), ',
'	"NOTE" VARCHAR2(100), ',
'	"INV_DIS" NUMBER(11,2), ',
'	"INV_NET" NUMBER(11,2), ',
'	"UP_DATE" DATE, ',
'	"USER_C" NUMBER(2,0), ',
'	"COMP_C" NUMBER(2,0), ',
'	"PAY_TYPE" NUMBER(1,0), ',
'	"CH_STORE_C" NUMBER(11,0), ',
'	"EMP_ID" NUMBER(3,0), ',
'	 CONSTRAINT "INVOICE_PK11" PRIMARY KEY ("INV_NO")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "INV_DETAIL" ',
'   (	"INV_NO" NUMBER(11,0), ',
'	"INV_DATE" DATE, ',
'	"INV_TYPE" NUMBER(1,0), ',
'	"STORE_NO" NUMBER(2,0), ',
'	"DEALER_C" NUMBER(3,0), ',
'	"DEALER_TYPE" NUMBER(1,0), ',
'	"ITEM_C" NUMBER(11,0), ',
'	"QTY" NUMBER(11,0), ',
'	"PRICE" NUMBER(11,2), ',
'	"ITEM_VAL" NUMBER(11,2), ',
'	"UOM" VARCHAR2(15), ',
'	"UP_DATE" DATE, ',
'	"COMP_C" NUMBER(2,0), ',
'	"PAY_TYPE" NUMBER(1,0), ',
'	"BAL_AFTER" NUMBER(11,2), ',
'	"I_SEQ" NUMBER(11,0), ',
'	"CH_STORE_C" NUMBER(11,0), ',
'	"NOTES" VARCHAR2(150), ',
'	"EMP_ID" VARCHAR2(3), ',
'	"CLASS_C" NUMBER, ',
'	"SEO" NUMBER, ',
'	 CONSTRAINT "INV_DETAIL_PK" PRIMARY KEY ("SEO")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "ITEMS" ',
'   (	"ITEM_C" NUMBER(11,0), ',
'	"ITEM_N" VARCHAR2(150), ',
'	"CLASS_C" NUMBER(11,0), ',
'	"FACTOR_C" NUMBER(2,0), ',
'	"MODEL" VARCHAR2(50), ',
'	"DEALER_C" NUMBER(11,0), ',
'	"STORE_NO" NUMBER(5,0), ',
'	"COST" NUMBER(11,2), ',
'	"PRICE" NUMBER(11,2), ',
'	"QTY" NUMBER(11,0), ',
'	"MIN_QTY" NUMBER(11,2), ',
'	"REORDER_QTY" NUMBER(11,2), ',
'	"BAR" VARCHAR2(300), ',
'	"UOM" VARCHAR2(15), ',
'	"USER_C" NUMBER(2,0), ',
'	"COMP_C" NUMBER(2,0), ',
'	"PRINT_ITEM" NUMBER, ',
'	 CONSTRAINT "ITEM_STORE_PK" PRIMARY KEY ("ITEM_C", "STORE_NO")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "ITEM_CARD" ',
'   (	"SERIAL" NUMBER, ',
'	"INV_NO" NUMBER(11,0), ',
'	"INV_DATE" DATE, ',
'	"INV_TYPE" NUMBER(1,0), ',
'	"STORE_NO" NUMBER(2,0), ',
'	"DEALER_C" NUMBER(3,0), ',
'	"DEALER_TYPE" NUMBER(1,0), ',
'	"DEALER_N" VARCHAR2(100), ',
'	"SEQ" NUMBER(2,0), ',
'	"ITEM_C" NUMBER(11,0), ',
'	"SANF_QTY" NUMBER(11,2), ',
'	"QTY" NUMBER(11,0), ',
'	"UOM" VARCHAR2(15), ',
'	"UP_DATE" DATE, ',
'	"USER_C" NUMBER(2,0), ',
'	"COMP_C" NUMBER(2,0), ',
'	"NOTE" VARCHAR2(100)',
'   ) ;',
'',
'  CREATE TABLE "ORG" ',
'   (	"ORG_ADDRESS" VARCHAR2(50), ',
'	"ORG_NAME" VARCHAR2(100)',
'   ) ;',
'',
'  CREATE TABLE "PAY_WAY" ',
'   (	"PAY_WAY" NUMBER(1,0), ',
'	"PAY_N" VARCHAR2(75)',
'   ) ;',
'',
'  CREATE TABLE "SANF" ',
'   (	"ITEM_C" NUMBER(11,0), ',
'	"CLASS_C" NUMBER(11,0) NOT NULL ENABLE, ',
'	"ITEM_N" VARCHAR2(200) NOT NULL ENABLE, ',
'	"UOM" VARCHAR2(15), ',
'	"DESCRIPTION" VARCHAR2(200), ',
'	"USER_C" NUMBER(2,0), ',
'	"COMP_C" NUMBER(2,0), ',
'	"BUY_PRICE" NUMBER(11,2), ',
'	"SALE_PRICE" NUMBER(11,2), ',
'	"REQ_POINT" NUMBER, ',
'	"STATE" NUMBER, ',
'	"PERCEND_SALE" NUMBER(2,3), ',
'	"SALE_PRICE_T" NUMBER(11,2), ',
'	"BAR" VARCHAR2(250), ',
'	 PRIMARY KEY ("ITEM_C")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "SANF_CARD" ',
'   (	"SERIAL" NUMBER, ',
'	"INV_NO" NUMBER(11,0), ',
'	"INV_DATE" DATE, ',
'	"INV_TYPE" NUMBER(1,0), ',
'	"STORE_NO" NUMBER(2,0), ',
'	"DEALER_C" NUMBER(3,0), ',
'	"DEALER_TYPE" NUMBER(1,0), ',
'	"DEALER_N" VARCHAR2(100), ',
'	"SEQ" NUMBER(2,0), ',
'	"ITEM_C" NUMBER(11,0), ',
'	"SANF_QTY" NUMBER(11,2), ',
'	"QTY" NUMBER(11,0), ',
'	"PRICE" NUMBER(11,2), ',
'	"ITEM_VAL" NUMBER(11,2), ',
'	"UOM" VARCHAR2(15), ',
'	"UP_DATE" DATE, ',
'	"USER_C" NUMBER(2,0), ',
'	"COMP_C" NUMBER(2,0), ',
'	"PAY_TYPE" NUMBER(1,0), ',
'	"SANF_QTY_B4" NUMBER(11,2), ',
'	"NOTE" VARCHAR2(100), ',
'	"I_SEQ" NUMBER',
'   ) ;',
'',
'  CREATE TABLE "STORE" ',
'   (	"STORE_no" NUMBER GENERATED BY DEFAULT ON NULL AS IDENTITY MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 25 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  NOT NULL ENABLE, ',
'	"STORE_N" VARCHAR2(255) NOT NULL ENABLE, ',
'	"ADDRESS" VARCHAR2(300), ',
'	"tel1" VARCHAR2(100), ',
'	"EMP_ID" NUMBER, ',
'	 CONSTRAINT "STORE_CON" PRIMARY KEY ("STORE_no")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE TABLE "UNITS" ',
'   (	"UNIT_C" NUMBER(2,0) NOT NULL ENABLE, ',
'	"UNIT_N" VARCHAR2(100)',
'   ) ;',
'',
'  CREATE TABLE "USERS" ',
'   (	"USER_ID" NUMBER, ',
'	"USER_NAME" VARCHAR2(255) NOT NULL ENABLE, ',
'	"PASSWORD" VARCHAR2(255) NOT NULL ENABLE, ',
'	 PRIMARY KEY ("USER_ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "USERS_U1" UNIQUE ("USER_NAME")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "BOX_t" ',
'before insert   ',
'on BOX for each row   ',
'begin   ',
':new.BOX_SEQ:=BOX_SEQ.nextval;   ',
'end;   ',
'  ',
' ',
'',
'/',
'ALTER TRIGGER "BOX_t" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "T_UP_BOX_DEALERS" AFTER update or delete or insert ',
' of AMOUNT_V ,TRANS_C on BOX FOR EACH ROW ',
'begin ',
'IF INSERTING THEN ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :NEW.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :NEW.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'END IF; ',
'----------------------------------------------------------------- ',
'IF DELETING THEN ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :OLD.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :OLD.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'END IF; ',
'----------------- ',
'IF UPDATING THEN ',
'-- FIRST STEP DELETE OLD VALUES ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :OLD.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :OLD.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'----------------------------------------------------------------- ',
'-- SECOUND STEP INSERT NEW VALUES ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :NEW.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :NEW.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'END IF; ',
'end; ',
'',
'/',
'ALTER TRIGGER "T_UP_BOX_DEALERS" ENABLE;',
'',
'  CREATE UNIQUE INDEX "BOX_BOX_C_PK" ON "BOX_OLD" ("BOX_SEQ") ',
'  ;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "BI_CLASS" ',
'  before insert on "CLASS"               ',
'  for each row  ',
'begin   ',
'  if :NEW."CLASS_C" is null then ',
'    select "CLASS_SEQ".nextval into :NEW."CLASS_C" from sys.dual; ',
'  end if; ',
'end; ',
'',
'/',
'ALTER TRIGGER "BI_CLASS" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "DECLEAR_NO" ',
'before insert  ',
'on DEALERS for each row  ',
'begin  ',
':new.DEALER_C:=DEALER_C_N.nextval;  ',
'end;  ',
' ',
'',
'/',
'ALTER TRIGGER "DECLEAR_NO" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "DEPT_TRG1" ',
'              before insert on dept',
'              for each row',
'              begin',
'                  if :new.deptno is null then',
'                      select dept_seq.nextval into :new.deptno from sys.dual;',
'                 end if;',
'              end;',
'/',
'ALTER TRIGGER "DEPT_TRG1" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "employeeid_t" ',
'before insert   ',
'on EMPLOYEE for each row   ',
'begin   ',
':new.EMP_ID:=empno_se.nextval;   ',
'end;   ',
'  ',
' ',
'',
'/',
'ALTER TRIGGER "employeeid_t" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "INVOICE_C_NO" ',
'before insert   ',
'on INVOICE for each row   ',
'begin   ',
':new.INV_NO:=INVNO_C_SE.nextval;   ',
'end;  ',
' ',
'',
'/',
'ALTER TRIGGER "INVOICE_C_NO" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "T_CUST" before insert or update or delete ',
'  of inv_type,inv_net,dealer_c on  invoice for each row ',
'begin ',
'if inserting then ',
'   update dealers ',
'   set sales = nvl(sales,0) + :new.inv_net ',
'   where :new.pay_type =  3   and dealer_c = :new.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if deleting then ',
'   update dealers ',
'   set sales = nvl(sales,0) - :old.inv_net ',
'   where :old.pay_type =  3   and dealer_c = :old.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if updating THEN ',
' IF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 ',
'   and :OLD.dealer_c <>:NEW.dealer_c THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :OLD.INV_NET ',
'   WHERE dealer_c = :new.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE =2 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 2 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET OR :NEW.PAY_TYPE =3 AND :OLD.PAY_TYPE = 2 ',
'   AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 ',
'   AND :OLD.PAY_TYPE = 3 AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3 ',
'   AND   :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' END IF; ',
' ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'    then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) - :OLD.INV_NET ',
'    WHERE dealer_c = :OLD.dealer_c and ',
'    dealer_type =2; ',
'  end if; ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'  then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) + :OLD.INV_NET ',
'    WHERE dealer_c = :new.dealer_c and dealer_type =2; ',
'  end if; ',
'END IF; ',
'end; ',
'',
'/',
'ALTER TRIGGER "T_CUST" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "T_DEALERS" before insert or update or delete ',
'  of dealer_c ,inv_net ,pay_type on  invoice for each row ',
'begin ',
'if updating THEN ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'    then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) - :OLD.INV_NET ',
'    WHERE dealer_c = :OLD.dealer_c and ',
'    dealer_type =2; ',
'  end if; ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'  then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) + :OLD.INV_NET ',
'    WHERE dealer_c = :new.dealer_c and dealer_type =2; ',
'  end if; ',
'end if; ',
'end; ',
'',
'/',
'ALTER TRIGGER "T_DEALERS" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "T_UP_INVOICE_DEALERS" after update or delete or insert ',
' on invoice ',
'begin ',
'------------------------------------------------------------------------ ',
'-- BUY AMOUNT ',
'  update dealers set BUY= 0; ',
'  update dealers ',
'  set BUY = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 1 ) ',
'  where dealer_type = 1; ',
'-------------------- ',
'-- BUY_DIS AMOUNT ',
'  update dealers ',
'  set DIS_VAL = 0 ',
'  where dealer_type = 1; ',
' ',
'  update dealers ',
'  set DIS_VAL = ',
'  (select nvl(sum(inv_DIS),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 1 ) ',
'  where dealer_type = 1; ',
'-------------------- ',
'-- BUY RETURN AMOUNT ',
'  update dealers ',
'  set BUY_return = 0; ',
'  update dealers ',
'  set BUY_return = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 4 ) ',
'  where dealer_type = 1; ',
'---------------------------------------------------------------------------- ',
'-- SALES AMOUNT ',
'  update dealers set sales = 0; ',
'  update dealers ',
'  set sales = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 3 ) ',
'  where dealer_type = 2; ',
'-------------------- ',
'-- DELAER_DIS AMOUNT ',
'  update dealers ',
'  set DIS_VAL = 0 ',
'  where dealer_type = 2; ',
' ',
'  update dealers ',
'  set DIS_VAL = ',
'  (select nvl(sum(inv_DIS),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 3 ) ',
'  where dealer_type = 2; ',
'---------------------- ',
'-- SALES RETURN AMOUNT ',
'  update dealers ',
'  set sales_return = 0; ',
'  update dealers ',
'  set sales_return = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 2 ) ',
'  where dealer_type = 2; ',
' ',
'------------------------------------------------- ',
' ',
'end; ',
'',
'/',
'ALTER TRIGGER "T_UP_INVOICE_DEALERS" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "UP_CUST_BAL" before insert or update or delete ',
'  on  invoice for each row ',
'begin ',
'if inserting then ',
'   update dealers ',
'   set sales = nvl(sales,0) + :new.inv_net ',
'   where :new.pay_type =  3 ',
'   and dealer_c = :new.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
'if deleting then ',
'   update dealers ',
'   set sales = nvl(sales,0) - :old.inv_net ',
'   where :old.pay_type =  3 ',
'   and dealer_c = :old.dealer_c ',
'      and   dealer_type =2; ',
'end if; ',
'if updating THEN ',
' IF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 1   AND :OLD.PAY_TYPE = 3 AND ',
'   :OLD.INV_NET = :NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3  AND ',
'   :OLD.INV_NET = :NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) - :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET = :NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 3 AND  :OLD.PAY_TYPE = 2  AND ',
'   :OLD.INV_NET = :NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 3 AND  :OLD.PAY_TYPE = 2  AND ',
'   :OLD.INV_NET<>:NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 1   AND :OLD.PAY_TYPE = 3 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3  AND ',
'   :OLD.INV_NET<>:NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' END IF; ',
'END IF; ',
'end;',
'/',
'ALTER TRIGGER "UP_CUST_BAL" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "UP_CUST_NEW" before insert or update or delete ',
'  of inv_type,inv_net on  invoice for each row ',
'begin ',
'if inserting then ',
'   update dealers ',
'   set sales = nvl(sales,0) + :new.inv_net ',
'   where :new.pay_type =  3   and dealer_c = :new.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if deleting then ',
'   update dealers ',
'   set sales = nvl(sales,0) - :old.inv_net ',
'   where :old.pay_type =  3   and dealer_c = :old.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if updating THEN ',
' IF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 ',
'   and :OLD.dealer_c <>:NEW.dealer_c THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :OLD.INV_NET ',
'   WHERE dealer_c = :new.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE =2 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 2 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET OR :NEW.PAY_TYPE =3 AND :OLD.PAY_TYPE = 2 ',
'   AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 ',
'   AND :OLD.PAY_TYPE = 3 AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3 ',
'   AND   :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; END IF; ',
'END IF; ',
'end;',
'/',
'ALTER TRIGGER "UP_CUST_NEW" ENABLE;',
'',
'  ALTER TABLE "INV_DETAIL" ADD CONSTRAINT "INV_DETAIL_CON" FOREIGN KEY ("INV_NO")',
'	  REFERENCES "INVOICE" ("INV_NO") ON DELETE CASCADE ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "INV_DETAIL_seq" ',
'before insert   ',
'on INV_DETAIL for each row   ',
'begin   ',
':new.SEO:= SEO_SE.nextval;   ',
'end;  ',
' ',
'',
'/',
'ALTER TRIGGER "INV_DETAIL_seq" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "T_ITEM_STORE2" ',
'before delete or insert or update ',
'of inv_type  ,qty on inv_detail for each row ',
'begin ',
'if  inserting  then ',
'    if :new.inv_type in (0,1,2,5)     then -- buy, sales_return,begin_store ',
'       update items ',
'       set qty = nvl(items.qty,0) + :new.qty , ',
'       cost = :new.price ',
'       where items.item_c      = :new.item_c ',
'       and     items.store_no  = :new.store_no; ',
'    end if; ',
' --------------------------------------------------------------------------------- ',
'    if :new.inv_type in (3,4)    then --  sales, buy_return ',
'       update items ',
'       set qty = nvl(items.qty,0) - :new.qty , ',
'       price = nvl(:new.price,0) ',
'       where items.item_c      = :new.item_c ',
'       and     items.store_no  = :new.store_no; ',
'    end if; ',
'end if; ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'if  updating then ',
'      if :new.inv_type in (0,1,2,5)    then -- buy, sales_return ',
'      update  items ',
'      set   qty = nvl(items.qty,0) + ( :new.qty - :old.qty ), ',
'      cost = :new.price ',
'      where items.item_c      = :old.item_c ',
'      and     items.store_no  = :old.store_no; ',
'    end if; ',
' --------------------------------------------------------------------------------- ',
'    if :new.inv_type in (3,4)    then --  sales, buy_return ',
'       update  items ',
'       set   qty =  nvl(items.qty,0) - ( :new.qty - :old.qty ), ',
'       price = :new.price ',
'       where items.item_c      = :old.item_c ',
'       and    items.store_no  = :old.store_no; ',
'    end if; ',
'end if; ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'if deleting then ',
'     if :old.inv_type in (0,1,2,5)    then -- buy, sales_return ',
'       update items ',
'       set qty = nvl(items.qty,0) - :old.qty , ',
'       cost = :old.price ',
'       where items.item_c      = :old.item_c ',
'       and     items.store_no  = :old.store_no; ',
'    end if; ',
'     if :old.inv_type in (3,4)    then --  sales, buy_return ',
'        update items ',
'        set qty = nvl(items.qty,0) + :old.qty, ',
'        price = :old.price ',
'        where items.item_c      = :old.item_c ',
'        and     items.store_no  = :old.store_no; ',
'    end if; ',
' ',
'end if; ',
'end;',
'/',
'ALTER TRIGGER "T_ITEM_STORE2" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "ITEM_C_NO" ',
'before insert   ',
'on SANF for each row   ',
'begin   ',
':new.ITEM_C:=ITEM_C_SE.nextval;   ',
'end;  ',
' ',
'',
'/',
'ALTER TRIGGER "ITEM_C_NO" ENABLE;',
'',
'  ALTER TABLE "STORE" ADD CONSTRAINT "EMP_ID_CO" FOREIGN KEY ("EMP_ID")',
'	  REFERENCES "EMPLOYEE" ("EMP_ID") ON DELETE CASCADE ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "UNITS_NO" ',
'before insert   ',
'on UNITS for each row   ',
'begin   ',
':new.UNIT_C:=UNIT_C_N.nextval;   ',
'end;  ',
' ',
'',
'/',
'ALTER TRIGGER "UNITS_NO" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "BI_USERS" ',
'',
' before insert on users ',
'',
' for each row ',
'',
'begin ',
'',
' -- Get a unique sequence value to use as the primary key',
'',
'select users_seq.nextval into :new.user_id from dual; ',
'',
' -- Make sure to save the username in upper case',
'',
':new.user_name := upper(:new.user_name); ',
' -- Hash the password so we are not saving clear text',
'',
' :new.password := hash_password(upper(:new.user_name), :new.password); ',
'',
'end;',
'/',
'ALTER TRIGGER "BI_USERS" ENABLE;',
'',
'  CREATE UNIQUE INDEX "BOX_BOX_C_PK" ON "BOX_OLD" ("BOX_SEQ") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "BOX_CON" ON "BOX" ("BOX_SEQ") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "CLASS_PK" ON "CLASS" ("CLASS_C") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "COMPANY_COMP_C_PK" ON "COMPANY" ("COMP_C") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "DEALERS_PK" ON "DEALERS" ("DEALER_C") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "EMPLOYEE_CON" ON "EMPLOYEE" ("EMP_ID") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "FACTORY_FACTOR_C_PK" ON "FACTORY" ("FACTOR_C") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "INVOICE_PK11" ON "INVOICE" ("INV_NO") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "INV_DETAIL_PK" ON "INV_DETAIL" ("SEO") ',
'  ;',
'',
'  CREATE UNIQUE INDEX "ITEM_STORE_PK" ON "ITEMS" ("ITEM_C", "STORE_NO") ',
'  ;',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'create or replace TRIGGER "BI_CLASS" ',
'  before insert on "CLASS"               ',
'  for each row  ',
'begin   ',
'  if :NEW."CLASS_C" is null then ',
'    select "CLASS_SEQ".nextval into :NEW."CLASS_C" from sys.dual; ',
'  end if; ',
'end; ',
'/',
'create or replace TRIGGER "BOX_t" ',
'before insert   ',
'on BOX for each row   ',
'begin   ',
':new.BOX_SEQ:=BOX_SEQ.nextval;   ',
'end;   ',
'  ',
' ',
'/',
'create or replace TRIGGER "DECLEAR_NO" ',
'before insert  ',
'on DEALERS for each row  ',
'begin  ',
':new.DEALER_C:=DEALER_C_N.nextval;  ',
'end;  ',
' ',
'/',
'create or replace TRIGGER "INVOICE_C_NO" ',
'before insert   ',
'on INVOICE for each row   ',
'begin   ',
':new.INV_NO:=INVNO_C_SE.nextval;   ',
'end;  ',
' ',
'/',
'create or replace TRIGGER "INV_DETAIL_seq" ',
'before insert   ',
'on INV_DETAIL for each row   ',
'begin   ',
':new.SEO:= SEO_SE.nextval;   ',
'end;  ',
' ',
'/',
'create or replace TRIGGER "ITEM_C_NO" ',
'before insert   ',
'on SANF for each row   ',
'begin   ',
':new.ITEM_C:=ITEM_C_SE.nextval;   ',
'end;  ',
' ',
'/',
'create or replace TRIGGER "T_CUST" before insert or update or delete ',
'  of inv_type,inv_net,dealer_c on  invoice for each row ',
'begin ',
'if inserting then ',
'   update dealers ',
'   set sales = nvl(sales,0) + :new.inv_net ',
'   where :new.pay_type =  3   and dealer_c = :new.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if deleting then ',
'   update dealers ',
'   set sales = nvl(sales,0) - :old.inv_net ',
'   where :old.pay_type =  3   and dealer_c = :old.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if updating THEN ',
' IF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE ='))
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(39380193110247259161)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' 3  AND :OLD.PAY_TYPE = 3 ',
'   and :OLD.dealer_c <>:NEW.dealer_c THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :OLD.INV_NET ',
'   WHERE dealer_c = :new.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE =2 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 2 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET OR :NEW.PAY_TYPE =3 AND :OLD.PAY_TYPE = 2 ',
'   AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 ',
'   AND :OLD.PAY_TYPE = 3 AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3 ',
'   AND   :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' END IF; ',
' ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'    then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) - :OLD.INV_NET ',
'    WHERE dealer_c = :OLD.dealer_c and ',
'    dealer_type =2; ',
'  end if; ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'  then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) + :OLD.INV_NET ',
'    WHERE dealer_c = :new.dealer_c and dealer_type =2; ',
'  end if; ',
'END IF; ',
'end; ',
'/',
'create or replace TRIGGER "T_DEALERS" before insert or update or delete ',
'  of dealer_c ,inv_net ,pay_type on  invoice for each row ',
'begin ',
'if updating THEN ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'    then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) - :OLD.INV_NET ',
'    WHERE dealer_c = :OLD.dealer_c and ',
'    dealer_type =2; ',
'  end if; ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'  then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) + :OLD.INV_NET ',
'    WHERE dealer_c = :new.dealer_c and dealer_type =2; ',
'  end if; ',
'end if; ',
'end; ',
'/',
'create or replace TRIGGER "T_ITEM_STORE2" ',
'before delete or insert or update ',
'of inv_type  ,qty on inv_detail for each row ',
'begin ',
'if  inserting  then ',
'    if :new.inv_type in (0,1,2,5)     then -- buy, sales_return,begin_store ',
'       update items ',
'       set qty = nvl(items.qty,0) + :new.qty , ',
'       cost = :new.price ',
'       where items.item_c      = :new.item_c ',
'       and     items.store_no  = :new.store_no; ',
'    end if; ',
' --------------------------------------------------------------------------------- ',
'    if :new.inv_type in (3,4)    then --  sales, buy_return ',
'       update items ',
'       set qty = nvl(items.qty,0) - :new.qty , ',
'       price = nvl(:new.price,0) ',
'       where items.item_c      = :new.item_c ',
'       and     items.store_no  = :new.store_no; ',
'    end if; ',
'end if; ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'if  updating then ',
'      if :new.inv_type in (0,1,2,5)    then -- buy, sales_return ',
'      update  items ',
'      set   qty = nvl(items.qty,0) + ( :new.qty - :old.qty ), ',
'      cost = :new.price ',
'      where items.item_c      = :old.item_c ',
'      and     items.store_no  = :old.store_no; ',
'    end if; ',
' --------------------------------------------------------------------------------- ',
'    if :new.inv_type in (3,4)    then --  sales, buy_return ',
'       update  items ',
'       set   qty =  nvl(items.qty,0) - ( :new.qty - :old.qty ), ',
'       price = :new.price ',
'       where items.item_c      = :old.item_c ',
'       and    items.store_no  = :old.store_no; ',
'    end if; ',
'end if; ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'if deleting then ',
'     if :old.inv_type in (0,1,2,5)    then -- buy, sales_return ',
'       update items ',
'       set qty = nvl(items.qty,0) - :old.qty , ',
'       cost = :old.price ',
'       where items.item_c      = :old.item_c ',
'       and     items.store_no  = :old.store_no; ',
'    end if; ',
'     if :old.inv_type in (3,4)    then --  sales, buy_return ',
'        update items ',
'        set qty = nvl(items.qty,0) + :old.qty, ',
'        price = :old.price ',
'        where items.item_c      = :old.item_c ',
'        and     items.store_no  = :old.store_no; ',
'    end if; ',
' ',
'end if; ',
'end;',
'/',
'create or replace TRIGGER "T_UP_BOX_DEALERS" AFTER update or delete or insert ',
' of AMOUNT_V ,TRANS_C on BOX FOR EACH ROW ',
'begin ',
'IF INSERTING THEN ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :NEW.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :NEW.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'END IF; ',
'----------------------------------------------------------------- ',
'IF DELETING THEN ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :OLD.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :OLD.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'END IF; ',
'----------------- ',
'IF UPDATING THEN ',
'-- FIRST STEP DELETE OLD VALUES ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :OLD.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :OLD.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'----------------------------------------------------------------- ',
'-- SECOUND STEP INSERT NEW VALUES ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :NEW.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :NEW.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'END IF; ',
'end; ',
'/',
'create or replace TRIGGER "T_UP_INVOICE_DEALERS" after update or delete or insert ',
' on invoice ',
'begin ',
'------------------------------------------------------------------------ ',
'-- BUY AMOUNT ',
'  update dealers set BUY= 0; ',
'  update dealers ',
'  set BUY = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 1 ) ',
'  where dealer_type = 1; ',
'-------------------- ',
'-- BUY_DIS AMOUNT ',
'  update dealers ',
'  set DIS_VAL = 0 ',
'  where dealer_type = 1; ',
' ',
'  update dealers ',
'  set DIS_VAL = ',
'  (select nvl(sum(inv_DIS),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 1 ) ',
'  where dealer_type = 1; ',
'-------------------- ',
'-- BUY RETURN AMOUNT ',
'  update dealers ',
'  set BUY_return = 0; ',
'  update dealers ',
'  set BUY_return = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 4 ) ',
'  where dealer_type = 1; ',
'---------------------------------------------------------------------------- ',
'-- SALES AMOUNT ',
'  update dealers set sales = 0; ',
'  update dealers ',
'  set sales = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 3 ) ',
'  where dealer_type = 2; ',
'-------------------- ',
'-- DELAER_DIS AMOUNT ',
'  update dealers ',
'  set DIS_VAL = 0 ',
'  where dealer_type = 2; ',
' ',
'  update dealers ',
'  set DIS_VAL = ',
'  (select nvl(sum(inv_DIS),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 3 ) ',
'  where dealer_type = 2; ',
'---------------------- ',
'-- SALES RETURN AMOUNT ',
'  update dealers ',
'  set sales_return = 0; ',
'  update dealers ',
'  set sales_return = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 2 ) ',
'  where dealer_type = 2; ',
' ',
'------------------------------------------------- ',
' ',
'end; ',
'/',
'create or replace TRIGGER "UNITS_NO" ',
'before insert   ',
'on UNITS for each row   ',
'begin   ',
':new.UNIT_C:=UNIT_C_N.nextval;   ',
'end;  ',
' ',
'/',
'create or replace TRIGGER "UP_CUST_BAL" before insert or update or delete ',
'  on  invoice for each row ',
'begin ',
'if inserting then ',
'   update dealers ',
'   set sales = nvl(sales,0) + :new.inv_net ',
'   where :new.pay_type =  3 ',
'   and dealer_c = :new.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
'if deleting then ',
'   update dealers ',
'   set sales = nvl(sales,0) - :old.inv_net ',
'   where :old.pay_type =  3 ',
'   and dealer_c = :old.dealer_c ',
'      and   dealer_type =2; ',
'end if; ',
'if updating THEN ',
' IF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 1   AND :OLD.PAY_TYPE = 3 AND ',
'   :OLD.INV_NET = :NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3  AND ',
'   :OLD.INV_NET = :NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) - :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET = :NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 3 AND  :OLD.PAY_TYPE = 2  AND ',
'   :OLD.INV_NET = :NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 3 AND  :OLD.PAY_TYPE = 2  AND ',
'   :OLD.INV_NET<>:NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 1   AND :OLD.PAY_TYPE = 3 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3  AND ',
'   :OLD.INV_NET<>:NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' END IF; ',
'END IF; ',
'end;',
'/',
'create or replace TRIGGER "UP_CUST_NEW" before insert or update or delete ',
'  of inv_type,inv_net on  invoice for each row ',
'begin ',
'if inserting then ',
'   update dealers ',
'   set sales = nvl(sales,0) + :new.inv_net ',
'   where :new.pay_type =  3   and dealer_c = :new.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if deleting then ',
'   update dealers ',
'   set sales = nvl(sales,0) - :old.inv_net ',
'   where :old.pay_type =  3   and dealer_c = :old.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if updating THEN ',
' IF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 ',
'   and :OLD.dealer_c <>:NEW.dealer_c THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :OLD.INV_NET ',
'   WHERE dealer_c = :new.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE =2 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 2 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET OR :NEW.PAY_TYPE =3 AND :OLD.PAY_TYPE = 2 ',
'   AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 ',
'   AND :OLD.PAY_TYPE = 3 AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3 ',
'   AND   :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; END IF; ',
'END IF; ',
'end;',
'/',
'create or replace TRIGGER "employeeid_t" ',
'before insert   ',
'on EMPLOYEE for each row   ',
'begin   ',
':new.EMP_ID:=empno_se.nextval;   ',
'end;   ',
'  ',
' ',
'/',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'create or replace PACKAGE "SPELL_NUMBER" ',
'IS ',
unistr('   /* \0647\0630\0647 \0627\0644\062F\0627\0644\0629 \062A\0642\0648\0645 \0628\0625\0633\062A\0642\0628\0627\0644 \0627\0644\0631\0642\0645 \0648\062A\0645\0631\064A\0631\0647 \0627\0644\064A \0627\0644\062F\0648\0627\0644 \0627\0644\0645\0646\0627\0633\0628\0629 \0644\062A\0647\062C\0626\062A\0647 \062D\0633\0628 \0639\062F\062F \062E\0627\0646\0627\062A \0627\0644\0631\0642\0645 \0627\0644\0645\0631\0631 \0644\0647\0627 \062B\0645 \062A\0642\0648\0645 \0628\0625\0633\062A\0631\062C\0627\0639\0647 */ '),
'   FUNCTION SPELL(digit NUMBER)RETURN VARCHAR2; ',
unistr('    /* \0647\0630\0647 \0627\0644\062F\0648\0627\0644 \0623\062F\0646\0627\0647 \062A\0642\0648\0645 \0628\062A\0647\062C\0626\0629 \0627\0644\0631\0642\0645 \062D\0633\0628 \0627\0644\062E\0627\0646\0627\062A \0627\0644\0645\0643\0648\0646\0629 \0644\0647 */ '),
'   FUNCTION SPELL_ONE_DIGIT(digit NUMBER) RETURN VARCHAR2; ',
'   FUNCTION SPELL_TWO_DIGIT(digit NUMBER) RETURN VARCHAR2; ',
'   FUNCTION SPELL_THREE_DIGIT(digit NUMBER) RETURN VARCHAR2; ',
'   FUNCTION SPELL_FOUR_DIGIT(digit NUMBER) RETURN VARCHAR2; ',
'   FUNCTION SPELL_FIVE_DIGIT(digit NUMBER) RETURN VARCHAR2; ',
'   FUNCTION SPELL_SIX_DIGIT(digit NUMBER) RETURN VARCHAR2; ',
'   FUNCTION SPELL_MILOEN_DIGIT(digit NUMBER) RETURN VARCHAR2; ',
unistr('   FUNCTION SPELL_MONEY(v_money_in number) RETURN VARCHAR2;--\062A\0642\0648\0645 \0628\062A\0641\0642\064A\0637 \0627\0644\0627\0645\0648\0627\0644 \0627\0644\064A \062C\0646\064A\0629 \0648\0642\0631\0634 '),
'END; ',
'/',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'create or replace PROCEDURE "CONSTRAINTS_MAKER" ',
'  ( TBL_NAME in VARCHAR2,ID_NAME in VARCHAR2) IS ',
'BEGIN ',
'  EXECUTE IMMEDIATE ''alter table ''||TBL_NAME||'' ADD  (constraint ''|| TBL_NAME ||''_''||ID_NAME||''_PK'' || ',
'  '' primary key  (''|| ID_NAME ||''))''; ',
'  commit; ',
'  DBMS_OUTPUT.PUT_LINE(''CONSTRAINT Primary key is '' ||   ID_NAME|| '' IN TABLE '' || TBL_NAME); ',
'end; ',
'/',
'create or replace PROCEDURE "FK_CONSTRAINT_MAKER" ',
'( TBL_NAME in VARCHAR2, ',
'ID_NAME in VARCHAR2, ',
'PARENT_TBL in VARCHAR2) IS ',
'BEGIN ',
'EXECUTE IMMEDIATE ''alter table ''||TBL_NAME|| ',
''' ADD(constraint ''|| TBL_NAME ||''_''||ID_NAME||''_FK ',
'  FOREIGN key  (''|| ID_NAME ||'') ',
'  References ''|| PARENT_TBL ||'' (''||ID_NAME ||''))''; ',
'DBMS_OUTPUT.PUT_LINE(''CONSTRAINT FOREIGN Key is '' || ID_NAME|| '' IN TABLE '' || TBL_NAME); ',
'end; ',
'/',
'create or replace PROCEDURE "INSERT_STORE_SANF" (store_id IN NUMBER) is ',
' ',
'	CURSOR C IS SELECT ITEM_C ,ITEM_N,CLASS_C,BUY_PRICE,SALE_PRICE,REQ_POINT FROM SANF ; ',
'V NUMBER; ',
'BEGIN ',
' ',
'	FOR C_REC IN C LOOP  ',
'	 SELECT COUNT(*) INTO V FROM ITEMS WHERE ITEM_C=C_REC.ITEM_C AND STORE_NO=store_id; ',
'		 ',
'		begin ',
' ',
' ',
'	 IF V=0 THEN  ',
'	   ',
'		INSERT into ITEMS (ITEM_C,ITEM_N,CLASS_C,STORE_NO,COST,PRICE,REORDER_QTY)VALUES(C_REC.ITEM_C,C_REC.ITEM_N,C_REC.CLASS_C,store_id,C_REC.BUY_PRICE,C_REC.SALE_PRICE,C_REC.REQ_POINT); ',
'		COMMIT; ',
' ',
' ',
'		END IF ; ',
' ',
'	end; ',
'	 ',
'END LOOP ; ',
' ',
'  ',
'	END;',
'/',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'create or replace FUNCTION AUTHENTICATE_USER',
'',
' (p_username in varchar2, ',
'',
'p_password in varchar2)',
'',
'return boolean',
'',
'is',
'',
' l_user_name users.user_name%type := upper(p_username);',
'',
' l_password users.password%type;',
'',
'  l_hashed_password varchar2(1000);',
'',
'  l_count number;',
'',
'begin',
'',
'-- Returns from the AUTHENTICATE_USER function ',
'',
unistr('--\00A0 \00A0 0\00A0 \00A0 Normal, successful authentication'),
'',
unistr('--\00A0 \00A0 1\00A0 \00A0 Unknown User Name'),
'',
unistr('--\00A0 \00A0 2\00A0 \00A0 Account Locked'),
'',
unistr('--\00A0 \00A0 3\00A0 \00A0 Account Expired'),
'',
unistr('--\00A0 \00A0 4\00A0 \00A0 Incorrect Password'),
'',
unistr('--\00A0 \00A0 5\00A0 \00A0 Password First Use'),
'',
unistr('--\00A0 \00A0 6\00A0 \00A0 Maximum Login Attempts Exceeded'),
'',
unistr('--\00A0 \00A0 7\00A0 \00A0 Unknown Internal Error'),
'',
'--',
'',
'-- First, check to see if the user exists',
'',
' select count(*) ',
'',
' into l_count ',
'',
'from users',
'',
'where user_name = l_user_name;',
'',
'',
'if l_count > 0 then',
'',
' -- Hash the password provided',
'',
' l_hashed_password := hash_password(l_user_name, p_password);',
'',
' ',
'',
' -- Get the stored password',
'',
' select password ',
'',
' into l_password ',
'',
'from users ',
'',
'where user_name = l_user_name;',
'',
'',
' -- Compare the two, and if there is a match, return TRUE',
'',
' if l_hashed_password = l_password then',
'',
' -- Good result. ',
'',
' APEX_UTIL.SET_AUTHENTICATION_RESULT(0);',
'',
'return true;',
'',
' else',
'',
'-- The Passwords didn''t match',
'',
' APEX_UTIL.SET_AUTHENTICATION_RESULT(4);',
'',
' return false;',
' end if;',
'',
' ',
'',
'else',
'',
' -- The username does not exist',
'',
' APEX_UTIL.SET_AUTHENTICATION_RESULT(1);',
'',
'return false;',
'',
' end if;',
'',
' -- If we get here then something weird happened. ',
'',
' APEX_UTIL.SET_AUTHENTICATION_RESULT(7);',
'',
' return false;',
'',
'exception ',
'',
' when others then ',
'',
'-- We don''t know what happened so log an unknown internal error',
'',
' APEX_UTIL.SET_AUTHENTICATION_RESULT(7);',
'',
'-- And save the SQL Error Message to the Auth Status.',
'',
'APEX_UTIL.SET_CUSTOM_AUTH_STATUS(sqlerrm);',
'',
' return false;',
'',
'',
'',
'end authenticate_user;',
'/',
'create or replace FUNCTION "TAFQEET" ( Nnum Number, Vintegercurrency Varchar2 := ''??, Vdecimalcurrency Varchar2 := ''?? )   ',
'Return   ',
'Varchar2   ',
'Is            ',
'vReturn   Varchar2(1000);  ',
'nInNum        Number := 0;   ',
'nInteger  Number := 0;      ',
'nDecimal  Number := 0;       ',
'nDecimal_V  varchar2(15) :=null;      ',
'vChar  Varchar2(100);          ',
'vTemp  Number := 0;         ',
'Type  NamesArray is table of Varchar2(500);   ',
'Namestr Namesarray := Namesarray   ',
'( '''',                     ',
'''??,                   ',
'''??,                 ',
'''??'',                ',
'''???,               ',
'''???,             ',
'''???'',           ',
'''????          ',
'''???             ',
');        ',
'Begin      ',
'nInNum   := ABS( nNum );   ',
'nInteger := Trunc( nInNum );   ',
'nDecimal := nInNum - nInteger;    ',
'nDecimal_V:=substr(to_char(nDecimal,''9D9999''),4,2);    ',
'vChar := To_Char( nInteger );       ',
'For I in 1..NameStr.Count Loop       ',
'If vChar is NULL Then               ',
'Exit;              ',
'End If;            ',
'vTemp := To_Number( SubStr( vChar, (Length( vChar )-2), 3) );   ',
'If vTemp>0 Then          ',
'vReturn := Digits3_Word( vTemp )||'' ''||NameStr( I )||'' ?|vReturn;  ',
'End If;          ',
'vChar := SubStr( vChar, 1, ( Length( vChar )-3 ) );    ',
'End Loop;         ',
'vReturn := SubStr( vReturn, 1, ( Length( vReturn )-1 ) );      ',
'vReturn := LTrim(RTrim(vReturn));        ',
'If nNum>=1000 and nNum<2000 Then        ',
'vReturn := SubStr( vReturn, 5, Length( vReturn ) );   ',
'End If;        ',
'If nNum>=2000 and nNum<3000 Then       ',
'vReturn := ''???||SubStr( vReturn, 11, Length( vReturn ) );     ',
'End If;          ',
'If nNum>=3000 and nNum<4000 Then       ',
'vReturn := ''????? ''||SubStr( vReturn, 11, Length( vReturn ) );     ',
'End If;  ',
'If nNum>=4000 and nNum<5000 Then       ',
'vReturn := ''????? ''||SubStr( vReturn, 11, Length( vReturn ) );     ',
'End If;  ',
'If nNum>=5000 and nNum<6000 Then       ',
'vReturn := ''?? ?? ''||SubStr( vReturn, 10, Length( vReturn ) );     ',
'End If;  ',
'If nNum>=6000 and nNum<7000 Then       ',
'vReturn := ''???? ''||SubStr( vReturn, 9, Length( vReturn ) );     ',
'End If;  ',
'If nNum>=7000 and nNum<8000 Then       ',
'vReturn := ''?? ?? ''||SubStr( vReturn, 10, Length( vReturn ) );     ',
'End If;  ',
'If nNum>=8000 and nNum<9000 Then       ',
'vReturn := ''????? ''||SubStr( vReturn, 11, Length( vReturn ) );     ',
'End If;  ',
'If nNum>=9000 and nNum<10000 Then       ',
'vReturn := ''?? ?? ''||SubStr( vReturn, 10, Length( vReturn ) );     ',
'End If;  ',
'If nNum>=10000 and nNum<11000 Then         ',
'vReturn := ''?? ?? ''||SubStr( vReturn, 10, Length( vReturn ) );   ',
'--vReturn := SubStr( vReturn,1,(INSTR( vReturn,''??'' )-1) )||''??||subStr( vReturn, (INSTR( vReturn, ''??)+3), Length( vReturn ) );    ',
'End If;     ',
'vReturn := LTrim(RTrim(vReturn));      ',
'If nDecimal>0 Then         ',
'If Vdecimalcurrency Is  Null Then   ',
'vReturn := vReturn||'' ''||vIntegerCurrency||''??''|| nDecimal_v || ''????  || '' ??'';    ',
'Else            ',
'vReturn := vReturn||'' ''||vIntegerCurrency||'' ?| nDecimal_v ||  vDecimalCurrency  || '' ?????;      ',
'end if;    ',
'Else        ',
'vReturn := vReturn||'' ''||vIntegerCurrency || '' ?????;    ',
'End If;     ',
'If nInteger>0 Then      ',
'vReturn := vReturn;    ',
'ElsIf nInteger=0 and nDecimal>0  Then     ',
'if vDecimalCurrency is  null then        ',
'Vreturn:=Ndecimal;            ',
'vReturn :=  ''??''||  nDecimal_v || '' ?? '' || '' ?????;  ',
'Else            ',
'vReturn := nDecimal_v || '' '' || vDecimalCurrency || ''?????;  ',
'end if;          ',
'Else             ',
'vReturn:=''??''||vIntegerCurrency || '' ?????;          ',
'End If;        ',
'Return (LTrim(RTrim(vReturn)));   ',
'End Tafqeet; ',
'/',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'   CREATE SEQUENCE  "BOX_SEQ"  MINVALUE 1 MAXVALUE 9999999999999 INCREMENT BY 1 START WITH 10 NOCACHE  ORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "CLASS_SE"  MINVALUE 1 MAXVALUE 9999999999999 INCREMENT BY 1 START WITH 125 NOCACHE  ORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "CLASS_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "DEALER_C_N"  MINVALUE 1 MAXVALUE 9999999999999 INCREMENT BY 1 START WITH 15 NOCACHE  ORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "EMPNO_SE"  MINVALUE 1 MAXVALUE 9999999999999 INCREMENT BY 1 START WITH 9 NOCACHE  ORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "INVNO_C_SE"  MINVALUE 1 MAXVALUE 9999999999999 INCREMENT BY 1 START WITH 66 NOCACHE  ORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "ITEM_C_SE"  MINVALUE 1 MAXVALUE 9999999999999 INCREMENT BY 1 START WITH 8801 NOCACHE  ORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "SANF_CARD_SEQ"  MINVALUE 1 MAXVALUE 999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  ORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "SEO_SE"  MINVALUE 1 MAXVALUE 9999999999999 INCREMENT BY 1 START WITH 125 NOCACHE  ORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'   CREATE SEQUENCE  "UNIT_C_N"  MINVALUE 1 MAXVALUE 9999999999999 INCREMENT BY 1 START WITH 16 NOCACHE  ORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;',
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "BUYER_QTY" ("ITEM_N", "BUY_QTY") AS ',
'  SELECT ALL inv4.sanf.item_n, SUM (inv4.inv_detail.qty) AS buy_qty ',
'         FROM inv4.inv_detail, inv4.sanf ',
'        WHERE (inv4.sanf.item_c = inv4.inv_detail.item_c) ',
'          AND inv_detail.inv_type = 1 ',
'     GROUP BY inv4.sanf.item_n ',
';',
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "BUYER_QTY_BACK" ("ITEM_N", "BUY_QTY_BACK") AS ',
'  SELECT ALL inv4.sanf.item_n, SUM (inv4.inv_detail.qty) AS buy_qty_back ',
'         FROM inv4.inv_detail, inv4.sanf ',
'        WHERE (inv4.sanf.item_c = inv4.inv_detail.item_c) ',
'          AND inv_detail.inv_type = 2 ',
'     GROUP BY inv4.sanf.item_n ',
';',
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "CUST_ACC" ("DEALER_C", "INV_NO", "ACC_RECIEVABLE", "DEBIT", "CREDIT", "DOC_DATE", "DOC_TYPE", "BOX_TYPE", "COMP_C") AS ',
'  SELECT    dealer_c,  inv_no,  acc_recievable,  debit,  credit, ',
'             doc_date, doc_type, box_type, comp_c ',
'       FROM (SELECT dealer_c, 0 acc_recievable, inv_no, inv_net  debit, 0 credit, ',
'                    inv_date doc_date, inv_type doc_type, 0 box_type, comp_c ',
'               FROM invoice ',
'              WHERE dealer_type = 2 AND inv_type = 3 ',
'             UNION ALL ',
'             SELECT dealer_c, 0 acc_recievable, inv_no, 0 debit, inv_net credit, ',
'                    inv_date doc_date, inv_type, 0 box_type, comp_c ',
'               FROM invoice ',
'              WHERE dealer_type = 2 AND inv_type =2 ',
'             UNION ALL ',
'             SELECT dealer_c, box_seq, 0 invoice_no, amount_v debit, 0 credit, ',
'                    box_date doc_date, 0 doc_type, box_type, comp_c ',
'               FROM box ',
'              WHERE dealer_type = 2 AND box_type = 2 ',
'             UNION ALL ',
'             SELECT dealer_c, box_seq, 0 invoice_no, 0 debit, amount_v credit, ',
'                    box_date doc_date, 0 doc_type, box_type, comp_c ',
'               FROM box ',
'              WHERE dealer_type = 2 AND box_type =1) ',
'   ORDER BY dealer_c, doc_date, inv_no, acc_recievable ',
';',
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "CUST_DETIAL" ("INV_NO", "INV_TYPE", "INV_DATE", "STORE_NO", "DEALER_C", "DEALER_TYPE", "INV_DIS", "INV_NET", "SEQ", "ITEM_C", "QTY", "PRICE", "ITEM_VAL", "ITEM_N") AS ',
'  SELECT ALL inv4.invoice.inv_no, inv4.invoice.inv_type, ',
'              inv4.invoice.inv_date, inv4.invoice.store_no, ',
'              inv4.invoice.dealer_c, inv4.invoice.dealer_type, ',
'              inv4.invoice.inv_dis, inv4.invoice.inv_net, inv4.inv_detail.SEO, ',
'              inv4.inv_detail.item_c, inv4.inv_detail.qty, ',
'              inv4.inv_detail.price, inv4.inv_detail.item_val, ',
'              inv4.sanf.item_n ',
'         FROM inv4.invoice, inv4.inv_detail, inv4.sanf ',
'        WHERE (    (inv4.invoice.inv_no = inv4.inv_detail.inv_no) ',
'               AND (inv4.invoice.inv_date = inv4.inv_detail.inv_date) ',
'               AND (inv4.invoice.inv_type = inv4.inv_detail.inv_type) ',
'               AND (inv4.invoice.store_no = inv4.inv_detail.store_no) ',
'               AND (inv4.sanf.item_c = inv4.inv_detail.item_c) ',
'               AND (inv4.invoice.inv_type = 3) ',
'               AND (inv4.invoice.dealer_type = 2) ',
'              ) ',
';',
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "ITEM_TRANS" ("INV_NO", "INV_DATE", "INV_TYPE", "STORE_NO", "ITEM_C", "INCREASE", "DECREASE", "BALANCE", "UOM", "DEALER_C", "DEALER_TYPE") AS ',
'  select inv_no,inv_date,inv_type, store_no,item_c,increase,  decrease , ',
'SUM(increase-decrease)  OVER (partition by item_c ORDER BY inv_type rows  between  unbounded  preceding and  current  row ) BALANCE , uom,dealer_c,dealer_type ',
'from ( ',
'select inv_no,inv_date,inv_type,store_no,item_c,qty increase,0 decrease ,  uom,dealer_c,dealer_type  ',
'from inv_detail ',
'where   ',
'inv_type in (0,1,2,5) ',
'union all ',
'select inv_no,inv_date,inv_type,store_no,item_c,0 increase,qty decrease , uom,dealer_c,dealer_type  ',
'from inv_detail ',
'where    ',
'inv_type in (3,4,6) ',
'order by item_c,inv_date,inv_type) ',
';',
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "SELL_QTY" ("ITEM_N", "SELL_QTY") AS ',
'  SELECT ALL inv4.sanf.item_n, SUM (inv4.inv_detail.qty) AS sell_qty ',
'         FROM inv4.inv_detail, inv4.sanf ',
'        WHERE (inv4.sanf.item_c = inv4.inv_detail.item_c) ',
'          AND inv_detail.inv_type = 3 ',
'     GROUP BY inv4.sanf.item_n ',
';',
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "SELL_QTY_BACK" ("ITEM_N", "SELL_QTY_BACK") AS ',
'  SELECT ALL inv4.sanf.item_n, SUM (inv4.inv_detail.qty) AS sell_qty_back ',
'         FROM inv4.inv_detail, inv4.sanf ',
'        WHERE (inv4.sanf.item_c = inv4.inv_detail.item_c) ',
'          AND inv_detail.inv_type = 4 ',
'     GROUP BY inv4.sanf.item_n ',
';',
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "SUPP_ACC" ("DEALER_C", "INV_NO", "ACC_PAYABLE", "DEBIT", "CREDIT", "DOC_DATE", "DOC_TYPE", "BOX_TYPE", "COMP_C") AS ',
'  select s_b.dealer_c,s_b.INV_NO,s_b.ACC_Payable ,s_b.debit,s_b.credit,s_b.doc_date,DOC_TYPE ,BOX_TYPE,Comp_C ',
'from ',
'(SELECT DEALER_C,0    ACC_Payable ,INV_NO,0   Debit,inv_net   Credit ,inv_DATE   DOC_DATE,INV_TYPE    DOC_TYPE, 0 BOX_TYPE,Comp_C ',
'FROM  INVOICE ',
'WHERE  DEALER_TYPE =1 ',
'and   inv_type =1 ',
'union ALL ',
'SELECT DEALER_C,0    ACC_Payable ,INV_NO,inv_net   Debit ,0    Credit ,inv_DATE   DOC_DATE,INV_TYPE,0 BOX_TYPE,Comp_C ',
'FROM  INVOICE'))
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.append_to_install_script(
 p_id=>wwv_flow_imp.id(39380193110247259161)
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
' ',
'WHERE  DEALER_TYPE =1 ',
'and   inv_type =4 ',
'union ALL ',
'select DEALER_C,BOX_SEQ ,0   INVOICE_NO, AMOUNT_V   DEBIT,0   CREDIT,BOX_DATE   DOC_DATE,0   DOC_TYPE ,BOX_TYPE ,Comp_C ',
'FROM BOX ',
'WHERE  DEALER_TYPE =1 ',
'AND BOX_TYPE =2 ',
'union ALL ',
'select DEALER_C,BOX_SEQ ,0   INVOICE_NO,0    DEBIT,AMOUNT_V   CREDIT,BOX_DATE   DOC_DATE,0   DOC_TYPE ,BOX_TYPE  ,Comp_C ',
'FROM BOX ',
'WHERE  DEALER_TYPE =1 ',
'AND BOX_TYPE =1 ',
'  ) s_b ',
'order by dealer_c,doc_date,inv_no,ACC_PAYABLE ',
';',
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "SUPP_DETIAL" ("INV_NO", "INV_TYPE", "INV_DATE", "STORE_NO", "DEALER_C", "DEALER_TYPE", "INV_DIS", "INV_NET", "SEQ", "ITEM_C", "QTY", "PRICE", "ITEM_VAL", "ITEM_N") AS ',
'  SELECT ALL inv4.invoice.inv_no, inv4.invoice.inv_type, ',
'              inv4.invoice.inv_date, inv4.invoice.store_no, ',
'              inv4.invoice.dealer_c, inv4.invoice.dealer_type, ',
'              inv4.invoice.inv_dis, inv4.invoice.inv_net, inv4.inv_detail.SEO, ',
'              inv4.inv_detail.item_c, inv4.inv_detail.qty, ',
'              inv4.inv_detail.price, inv4.inv_detail.item_val, ',
'              inv4.sanf.item_n ',
'         FROM inv4.invoice, inv4.inv_detail, inv4.sanf ',
'        WHERE (    (inv4.invoice.inv_no = inv4.inv_detail.inv_no) ',
'               AND (inv4.invoice.inv_date = inv4.inv_detail.inv_date) ',
'               AND (inv4.invoice.inv_type = inv4.inv_detail.inv_type) ',
'               AND (inv4.invoice.store_no = inv4.inv_detail.store_no) ',
'               AND (inv4.sanf.item_c = inv4.inv_detail.item_c) ',
'               AND (inv4.invoice.inv_type = 1) ',
'               AND (inv4.invoice.dealer_type = 1) ',
'              ) ',
';',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "BOX_t" ',
'before insert   ',
'on BOX for each row   ',
'begin   ',
':new.BOX_SEQ:=BOX_SEQ.nextval;   ',
'end;   ',
'  ',
' ',
'',
'/',
'ALTER TRIGGER "BOX_t" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "T_UP_BOX_DEALERS" AFTER update or delete or insert ',
' of AMOUNT_V ,TRANS_C on BOX FOR EACH ROW ',
'begin ',
'IF INSERTING THEN ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :NEW.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :NEW.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'END IF; ',
'----------------------------------------------------------------- ',
'IF DELETING THEN ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :OLD.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :OLD.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'END IF; ',
'----------------- ',
'IF UPDATING THEN ',
'-- FIRST STEP DELETE OLD VALUES ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :OLD.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :OLD.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) - :OLD.AMOUNT_V ',
'    where  dealers.dealer_c = :OLD.dealer_c AND :OLD.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'----------------------------------------------------------------- ',
'-- SECOUND STEP INSERT NEW VALUES ',
'-- SUPPLIER -- -- AMOUNT RECIEVED TO SUPPLIER ',
'   IF :NEW.TRANS_C =1 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 1; ',
'  -------------------- ',
'  --AMOUNT PAYED TO SUPPLIER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 1; ',
'   END IF; ',
'   -------------------------------------------------------------- ',
'-- CUSTOMER -- -- AMOUNT RECIEVED TO CUSTOMER ',
'   IF :NEW.TRANS_C =2 THEN ',
'    update dealers set CASH_IN= NVL(CASH_IN,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=1 ',
'    AND dealer_type = 2; ',
'  -------------------- ',
'  --AMOUNT PAYED TO CUSTOMER ',
'    update dealers set CASH_OUT= NVL(CASH_OUT,0) + :NEW.AMOUNT_V ',
'    where  dealers.dealer_c = :NEW.dealer_c AND :NEW.BOX_TYPE=2 ',
'    AND dealer_type = 2; ',
'   END IF; ',
'END IF; ',
'end; ',
'',
'/',
'ALTER TRIGGER "T_UP_BOX_DEALERS" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "BI_CLASS" ',
'  before insert on "CLASS"               ',
'  for each row  ',
'begin   ',
'  if :NEW."CLASS_C" is null then ',
'    select "CLASS_SEQ".nextval into :NEW."CLASS_C" from sys.dual; ',
'  end if; ',
'end; ',
'',
'/',
'ALTER TRIGGER "BI_CLASS" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "DECLEAR_NO" ',
'before insert  ',
'on DEALERS for each row  ',
'begin  ',
':new.DEALER_C:=DEALER_C_N.nextval;  ',
'end;  ',
' ',
'',
'/',
'ALTER TRIGGER "DECLEAR_NO" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "DEPT_TRG1" ',
'              before insert on dept',
'              for each row',
'              begin',
'                  if :new.deptno is null then',
'                      select dept_seq.nextval into :new.deptno from sys.dual;',
'                 end if;',
'              end;',
'/',
'ALTER TRIGGER "DEPT_TRG1" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "employeeid_t" ',
'before insert   ',
'on EMPLOYEE for each row   ',
'begin   ',
':new.EMP_ID:=empno_se.nextval;   ',
'end;   ',
'  ',
' ',
'',
'/',
'ALTER TRIGGER "employeeid_t" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "INVOICE_C_NO" ',
'before insert   ',
'on INVOICE for each row   ',
'begin   ',
':new.INV_NO:=INVNO_C_SE.nextval;   ',
'end;  ',
' ',
'',
'/',
'ALTER TRIGGER "INVOICE_C_NO" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "T_CUST" before insert or update or delete ',
'  of inv_type,inv_net,dealer_c on  invoice for each row ',
'begin ',
'if inserting then ',
'   update dealers ',
'   set sales = nvl(sales,0) + :new.inv_net ',
'   where :new.pay_type =  3   and dealer_c = :new.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if deleting then ',
'   update dealers ',
'   set sales = nvl(sales,0) - :old.inv_net ',
'   where :old.pay_type =  3   and dealer_c = :old.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if updating THEN ',
' IF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 ',
'   and :OLD.dealer_c <>:NEW.dealer_c THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :OLD.INV_NET ',
'   WHERE dealer_c = :new.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE =2 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 2 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET OR :NEW.PAY_TYPE =3 AND :OLD.PAY_TYPE = 2 ',
'   AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 ',
'   AND :OLD.PAY_TYPE = 3 AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3 ',
'   AND   :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' END IF; ',
' ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'    then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) - :OLD.INV_NET ',
'    WHERE dealer_c = :OLD.dealer_c and ',
'    dealer_type =2; ',
'  end if; ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'  then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) + :OLD.INV_NET ',
'    WHERE dealer_c = :new.dealer_c and dealer_type =2; ',
'  end if; ',
'END IF; ',
'end; ',
'',
'/',
'ALTER TRIGGER "T_CUST" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "T_DEALERS" before insert or update or delete ',
'  of dealer_c ,inv_net ,pay_type on  invoice for each row ',
'begin ',
'if updating THEN ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'    then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) - :OLD.INV_NET ',
'    WHERE dealer_c = :OLD.dealer_c and ',
'    dealer_type =2; ',
'  end if; ',
'  IF :NEW.dealer_c<>:OLD.dealer_c and :old.pay_type =3 and :new.pay_type= 3 ',
'  then UPDATE DEALERS ',
'    SET sales = nvl(sales,0) + :OLD.INV_NET ',
'    WHERE dealer_c = :new.dealer_c and dealer_type =2; ',
'  end if; ',
'end if; ',
'end; ',
'',
'/',
'ALTER TRIGGER "T_DEALERS" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "T_UP_INVOICE_DEALERS" after update or delete or insert ',
' on invoice ',
'begin ',
'------------------------------------------------------------------------ ',
'-- BUY AMOUNT ',
'  update dealers set BUY= 0; ',
'  update dealers ',
'  set BUY = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 1 ) ',
'  where dealer_type = 1; ',
'-------------------- ',
'-- BUY_DIS AMOUNT ',
'  update dealers ',
'  set DIS_VAL = 0 ',
'  where dealer_type = 1; ',
' ',
'  update dealers ',
'  set DIS_VAL = ',
'  (select nvl(sum(inv_DIS),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 1 ) ',
'  where dealer_type = 1; ',
'-------------------- ',
'-- BUY RETURN AMOUNT ',
'  update dealers ',
'  set BUY_return = 0; ',
'  update dealers ',
'  set BUY_return = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 4 ) ',
'  where dealer_type = 1; ',
'---------------------------------------------------------------------------- ',
'-- SALES AMOUNT ',
'  update dealers set sales = 0; ',
'  update dealers ',
'  set sales = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 3 ) ',
'  where dealer_type = 2; ',
'-------------------- ',
'-- DELAER_DIS AMOUNT ',
'  update dealers ',
'  set DIS_VAL = 0 ',
'  where dealer_type = 2; ',
' ',
'  update dealers ',
'  set DIS_VAL = ',
'  (select nvl(sum(inv_DIS),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 3 ) ',
'  where dealer_type = 2; ',
'---------------------- ',
'-- SALES RETURN AMOUNT ',
'  update dealers ',
'  set sales_return = 0; ',
'  update dealers ',
'  set sales_return = ',
'  (select nvl(sum(inv_net),0) from invoice where ',
'  invoice.dealer_c = dealers.dealer_c and inv_type = 2 ) ',
'  where dealer_type = 2; ',
' ',
'------------------------------------------------- ',
' ',
'end; ',
'',
'/',
'ALTER TRIGGER "T_UP_INVOICE_DEALERS" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "UP_CUST_BAL" before insert or update or delete ',
'  on  invoice for each row ',
'begin ',
'if inserting then ',
'   update dealers ',
'   set sales = nvl(sales,0) + :new.inv_net ',
'   where :new.pay_type =  3 ',
'   and dealer_c = :new.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
'if deleting then ',
'   update dealers ',
'   set sales = nvl(sales,0) - :old.inv_net ',
'   where :old.pay_type =  3 ',
'   and dealer_c = :old.dealer_c ',
'      and   dealer_type =2; ',
'end if; ',
'if updating THEN ',
' IF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 1   AND :OLD.PAY_TYPE = 3 AND ',
'   :OLD.INV_NET = :NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3  AND ',
'   :OLD.INV_NET = :NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) - :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET = :NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 3 AND  :OLD.PAY_TYPE = 2  AND ',
'   :OLD.INV_NET = :NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 3 AND  :OLD.PAY_TYPE = 2  AND ',
'   :OLD.INV_NET<>:NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 1   AND :OLD.PAY_TYPE = 3 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET    OR ',
'   :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3  AND ',
'   :OLD.INV_NET<>:NEW.INV_NET   THEN ',
'   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' END IF; ',
'END IF; ',
'end;',
'/',
'ALTER TRIGGER "UP_CUST_BAL" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "UP_CUST_NEW" before insert or update or delete ',
'  of inv_type,inv_net on  invoice for each row ',
'begin ',
'if inserting then ',
'   update dealers ',
'   set sales = nvl(sales,0) + :new.inv_net ',
'   where :new.pay_type =  3   and dealer_c = :new.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if deleting then ',
'   update dealers ',
'   set sales = nvl(sales,0) - :old.inv_net ',
'   where :old.pay_type =  3   and dealer_c = :old.dealer_c ',
'   and   dealer_type =2; ',
'end if; ',
' ',
'if updating THEN ',
' IF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3  AND :OLD.PAY_TYPE = 3 ',
'   and :OLD.dealer_c <>:NEW.dealer_c THEN ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ',
'   UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :OLD.INV_NET ',
'   WHERE dealer_c = :new.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE =2 AND :OLD.PAY_TYPE =3 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) - :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND :OLD.INV_NET = :NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 2 AND :OLD.INV_NET = :NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE = 3 AND :OLD.PAY_TYPE = 1 AND ',
'   :OLD.INV_NET<>:NEW.INV_NET OR :NEW.PAY_TYPE =3 AND :OLD.PAY_TYPE = 2 ',
'   AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN UPDATE DEALERS ',
'   SET sales = nvl(sales,0) + :NEW.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; ',
' ELSIF :NEW.PAY_TYPE =1 ',
'   AND :OLD.PAY_TYPE = 3 AND  :OLD.INV_NET<>:NEW.INV_NET ',
'   OR  :NEW.PAY_TYPE = 2 AND  :OLD.PAY_TYPE = 3 ',
'   AND   :OLD.INV_NET<>:NEW.INV_NET ',
'   THEN   UPDATE DEALERS SET sales = nvl(sales,0) - :OLD.INV_NET ',
'   WHERE dealer_c = :OLD.dealer_c ',
'   and   dealer_type =2; END IF; ',
'END IF; ',
'end;',
'/',
'ALTER TRIGGER "UP_CUST_NEW" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "INV_DETAIL_seq" ',
'before insert   ',
'on INV_DETAIL for each row   ',
'begin   ',
':new.SEO:= SEO_SE.nextval;   ',
'end;  ',
' ',
'',
'/',
'ALTER TRIGGER "INV_DETAIL_seq" ENABLE;',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "T_ITEM_STORE2" ',
'before delete or insert or update ',
'of inv_type  ,qty on inv_detail for each row ',
'begin ',
'if  inserting  then ',
'    if :new.inv_type in (0,1,2,5)     then -- buy, sales_return,begin_store ',
'       update items ',
'       set qty = nvl(items.qty,0) + :new.qty , ',
'       cost = :new.price ',
'       where items.item_c      = :new.item_c ',
'       and     items.store_no  = :new.store_no; ',
'    end if; ',
' --------------------------------------------------------------------------------- ',
'    if :new.inv_type in (3,4)    then --  sales, buy_return ',
'       update items ',
'       set qty = nvl(items.qty,0) - :new.qty , ',
'       price = nvl(:new.price,0) ',
'       where items.item_c      = :new.item_c ',
'       and     items.store_no  = :new.store_no; ',
'    end if; ',
'end if; ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'if  updating then ',
'      if :new.inv_type in (0,1,2,5)    then -- buy, sales_return ',
'      update  items ',
'      set   qty = nvl(items.qty,0) + ( :new.qty - :old.qty ), ',
'      cost = :new.price ',
'      where items.item_c      = :old.item_c ',
'      and     items.store_no  = :old.store_no; ',
'    end if; ',
' --------------------------------------------------------------------------------- ',
'    if :new.inv_type in (3,4)    then --  sales, buy_return ',
'       update  items ',
'       set   qty =  nvl(items.qty,0) - ( :new.qty - :old.qty ), ',
'       price = :new.price ',
'       where items.item_c      = :old.item_c ',
'       and    items.store_no  = :old.store_no; ',
'    end if; ',
'end if; ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'------------------------------------------------------------------------------------------------------------------------------ ',
'if deleting then ',
'     if :old.inv_type in (0,1,2,5)    then -- buy, sales_return ',
'       update items ',
'       set qty = nvl(items.qty,0) - :old.qty , ',
'       cost = :old.price ',
'       where items.item_c      = :old.item_c ',
'       and     items.store_no  = :old.store_no; ',
'    end if; ',
'     if :old.inv_type in (3,4)    then --  sales, buy_return ',
'        update items ',
'        set qty = nvl(items.qty,0) + :old.qty, ',
'        price = :old.price ',
'        where items.item_c      = :old.item_c ',
'        and     items.store_no  = :old.store_no; ',
'    end if; ',
' ',
'end if; ',
'end;',
'/',
'ALTER TRIGGER "T_ITEM_STORE2" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "ITEM_C_NO" ',
'before insert   ',
'on SANF for each row   ',
'begin   ',
':new.ITEM_C:=ITEM_C_SE.nextval;   ',
'end;  ',
' ',
'',
'/',
'ALTER TRIGGER "ITEM_C_NO" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "UNITS_NO" ',
'before insert   ',
'on UNITS for each row   ',
'begin   ',
':new.UNIT_C:=UNIT_C_N.nextval;   ',
'end;  ',
' ',
'',
'/',
'ALTER TRIGGER "UNITS_NO" ENABLE;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER "BI_USERS" ',
'',
' before insert on users ',
'',
' for each row ',
'',
'begin ',
'',
' -- Get a unique sequence value to use as the primary key',
'',
'select users_seq.nextval into :new.user_id from dual; ',
'',
' -- Make sure to save the username in upper case',
'',
':new.user_name := upper(:new.user_name); ',
' -- Hash the password so we are not saving clear text',
'',
' :new.password := hash_password(upper(:new.user_name), :new.password); ',
'',
'end;',
'/',
'ALTER TRIGGER "BI_USERS" ENABLE;',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'create or replace PACKAGE BODY "SPELL_NUMBER" ',
'IS ',
' ',
'  FUNCTION SPELL(digit NUMBER)RETURN VARCHAR2 ',
'  IS ',
'    v_spell varchar2(100); ',
'    count_digit number; ',
'  BEGIN ',
'    count_digit:=LENGTH(digit); ',
' ',
'CASE ',
'  WHEN count_digit = 1 THEN ',
'    v_spell:= spell_one_digit(digit); ',
'  WHEN count_digit = 2 THEN ',
'    v_spell:= spell_two_digit(digit); ',
'  WHEN count_digit = 3 THEN ',
'    v_spell:= spell_THREE_digit(digit); ',
'  WHEN count_digit = 4 THEN ',
'    v_spell:= spell_four_digit(digit); ',
'  WHEN count_digit = 5 THEN ',
'    v_spell:= spell_five_digit(digit); ',
'  WHEN count_digit = 6 THEN ',
'    v_spell:= spell_six_digit(digit); ',
'  WHEN count_digit IN(7,8) THEN ',
'    v_spell:= spell_miloen_digit(digit); ',
'  ELSE ',
'    v_spell:= ''NUMBER MUST BE BETWEEN 1 AND 99999999''; ',
'  END CASE; ',
'  RETURN v_spell; ',
'  END SPELL; ',
' ',
' ',
'FUNCTION SPELL_ONE_DIGIT(digit NUMBER) RETURN VARCHAR2 ',
'IS ',
'  v_spell varchar2(100); ',
' ',
'BEGIN ',
' ',
'  CASE ',
'  WHEN digit=1 THEN ',
unistr('    v_spell:=''\0648\0627\062D\062F''; '),
'  WHEN digit=2 THEN ',
unistr('    v_spell:=''\0625\062B\0646\0627\0646''; '),
'  WHEN digit = 3 THEN ',
unistr('    v_spell:=''\062B\0644\0627\062B\0629''; '),
'  WHEN digit = 4 THEN ',
unistr('    v_spell:=''\0623\0631\0628\0639\0629''; '),
'  WHEN digit = 5 THEN ',
unistr('    v_spell:=''\062E\0645\0633\0629''; '),
'  WHEN digit = 6 THEN ',
unistr('    v_spell:=''\0633\062A\0629''; '),
'  WHEN digit = 7 THEN ',
unistr('    v_spell:=''\0633\0628\0639\0629''; '),
'  WHEN digit = 8 THEN ',
unistr('    v_spell:=''\062B\0645\0627\0646\064A\0629''; '),
'  WHEN digit = 9 THEN ',
unistr('    v_spell:=''\062A\0633\0639\0629''; '),
'ELSE ',
'  RETURN null; ',
'END CASE; ',
'  RETURN v_spell; ',
'END SPELL_ONE_DIGIT; ',
' ',
'FUNCTION SPELL_TWO_DIGIT(digit NUMBER) RETURN VARCHAR2 ',
'IS ',
'  v_spell varchar2(20); ',
' ',
'  FUNCTION TY(dig NUMBER)RETURN VARCHAR2 ',
'   IS ',
'     v_spel varchar2(7); ',
'   BEGIN ',
'     CASE ',
'     WHEN dig = 20 THEN ',
unistr('    v_spel:=''\0639\0634\0631\0648\0646''; '),
'      WHEN dig = 30 THEN ',
unistr('    v_spel:=''\062B\0644\0627\062B\0648\0646''; '),
'      WHEN dig = 40 THEN ',
unistr('    v_spel:=''\0623\0631\0628\0639\0648\0646''; '),
'      WHEN dig = 50 THEN ',
unistr('    v_spel:=''\062E\0645\0633\0648\0646''; '),
'      WHEN dig = 60 THEN ',
unistr('    v_spel:=''\0633\062A\0648\0646''; '),
'      WHEN dig = 70 THEN ',
unistr('    v_spel:=''\0633\0628\0639\0648\0646''; '),
'      WHEN dig = 80 THEN ',
unistr('    v_spel:=''\062B\0645\0627\0646\0648\0646''; '),
'      WHEN dig = 90 THEN ',
unistr('    v_spel:=''\062A\0633\0639\0648\0646''; '),
'  ELSE ',
'   RETURN NULL; ',
'  END CASE; ',
'   RETURN v_spel; ',
'  END TY; ',
' ',
'BEGIN ',
' ',
' CASE ',
'  WHEN digit = 10 THEN ',
unistr('    v_spell:=''\0639\0634\0631\0629''; '),
'  WHEN digit = 11 THEN ',
unistr('    v_spell:=''\0625\062D\062F\0649 \0639\0634\0631''; '),
'  WHEN digit = 12 THEN ',
unistr('    v_spell:=''\0625\062B\0646\0627\0639\0634\0631''; '),
'  WHEN digit BETWEEN 13 AND 19 THEN ',
unistr('    v_spell:=SPELL_ONE_DIGIT(substr(digit,2,2))||''\0639\0634\0631\0629''; '),
'  WHEN digit in(20,30,40,50,60,70,80,90) THEN ',
'    RETURN TY(digit); ',
'  WHEN digit BETWEEN 21 AND 99  THEN ',
unistr('  v_spell:=SPELL_ONE_DIGIT(substr(digit,2,2))||'' \0648 ''||TY(substr(digit,1,1)||0); '),
'  ELSE ',
'  v_spell:= null; ',
'  END CASE; ',
'  RETURN v_spell; ',
' ',
'END SPELL_TWO_DIGIT; ',
' ',
'FUNCTION SPELL_THREE_DIGIT(digit NUMBER) RETURN VARCHAR2 ',
'IS ',
'   v_spell varchar2(100); ',
' ',
'   FUNCTION HUNDRED(dig NUMBER)RETURN VARCHAR2 ',
'   IS ',
'     v_spel varchar2(20); ',
'   BEGIN ',
'   CASE ',
'    WHEN dig = 100 THEN ',
unistr('      v_spel:=''\0645\0627\0626\0629''; '),
'    WHEN dig = 200 THEN ',
unistr('      v_spel:=''\0645\0626\062A\0627\0646''; '),
'    WHEN dig = 300 THEN ',
unistr('      v_spel:=''\062B\0644\0627\062B\0645\0627\0626\0629''; '),
'    WHEN dig = 400 THEN ',
unistr('      v_spel:=''\0623\0631\0628\0639\0645\0627\0626\0629''; '),
'    WHEN dig = 500 THEN ',
unistr('      v_spel:=''\062E\0645\0633\0645\0627\0626\0629''; '),
'    WHEN dig = 600 THEN ',
unistr('      v_spel:=''\0633\062A\0645\0627\0626\0629''; '),
'    WHEN dig = 700 THEN ',
unistr('      v_spel:=''\0633\0628\0639\0645\0627\0626\0629''; '),
'    WHEN dig = 800 THEN ',
unistr('      v_spel:=''\062B\0645\0627\0646\0645\0627\0626\0629''; '),
'    WHEN dig = 900 THEN ',
unistr('      v_spel:=''\062A\0633\0639\0645\0627\0626\0629''; '),
'  ELSE ',
'   v_spel:= NULL; ',
'  END CASE; ',
'   RETURN v_spel; ',
'  END HUNDRED; ',
' ',
'BEGIN --SPELL_THREE_DIGIT ',
' CASE ',
'  WHEN digit in(100,200,300,400,500,600,700,800,900) THEN ',
'    RETURN hundred(digit); ',
'  WHEN digit BETWEEN 100 AND 999  THEN ',
unistr('  v_spell:= hundred(substr(digit,1,1)||''00'')||'' \0648 ''||SPELL(substr(digit,2)); '),
'  ELSE ',
'  v_spell:= null; ',
'  END CASE; ',
'  RETURN v_spell; ',
' ',
'END SPELL_THREE_DIGIT; ',
' ',
'FUNCTION SPELL_FOUR_DIGIT(digit NUMBER) RETURN VARCHAR2 ',
'IS ',
' ',
'   v_spell varchar2(100); ',
' ',
'   FUNCTION SOTHAND(dig NUMBER)RETURN VARCHAR2 ',
'   IS ',
'     v_spel varchar2(40); ',
'   BEGIN ',
'   CASE ',
'    WHEN dig = 1000 THEN ',
unistr('      v_spel:=''\0623\0644\0641''; '),
'    WHEN dig = 2000 THEN ',
unistr('      v_spel:=''\0623\0644\0641\0627\0646''; '),
'    WHEN dig = 3000 THEN ',
unistr('      v_spel:=''\062B\0644\0627\062B\0629 \0622\0644\0627\0641''; '),
'    WHEN dig = 4000 THEN ',
unistr('      v_spel:=''\0623\0631\0628\0639\0629 \0622\0644\0627\0641''; '),
'    WHEN dig = 5000 THEN ',
unistr('      v_spel:=''\062E\0645\0633\0629 \0622\0644\0627\0641''; '),
'    WHEN dig = 6000 THEN ',
unistr('      v_spel:=''\0633\062A\0629 \0622\0644\0627\0641''; '),
'    WHEN dig = 7000 THEN ',
unistr('      v_spel:=''\0633\0628\0639\0629 \0622\0644\0627\0641''; '),
'    WHEN dig = 8000 THEN ',
unistr('      v_spel:=''\062B\0645\0627\0646\064A\0629 \0622\0644\0627\0641''; '),
'    WHEN dig = 9000 THEN ',
unistr('      v_spel:=''\062A\0633\0639\0629 \0622\0644\0627\0641''; '),
'  ELSE ',
'   v_spel:= NULL; ',
'  END CASE; ',
'   RETURN v_spel; ',
'  END SOTHAND; ',
' ',
'BEGIN --SPELL_FOUR_DIGIT ',
' ',
'CASE ',
'  WHEN digit in(1000,2000,3000,4000,5000,6000,7000,8000,9000) THEN ',
'    RETURN SOTHAND(digit); ',
'  WHEN digit BETWEEN 1000 AND 9999  THEN ',
unistr('  v_spell:= SOTHAND(substr(digit,1,1)||''000'')||'' \0648 ''||SPELL(substr(digit,2)); '),
'  ELSE ',
'  v_spell:= null; ',
'  END CASE; ',
'  RETURN v_spell; ',
' ',
'END SPELL_FOUR_DIGIT; ',
' ',
'FUNCTION SPELL_FIVE_DIGIT(digit NUMBER) RETURN VARCHAR2 ',
'IS ',
'  v_spell varchar2(100); ',
'BEGIN ',
'  CASE ',
'   WHEN SUBSTR(digit,3) = 000 THEN ',
unistr('    RETURN spell_two_digit(substr(digit,1,2))||'' \0623\0644\0641 ''; '),
'   WHEN digit BETWEEN 10000 AND 99999 THEN ',
unistr('    v_spell:=spell_two_digit(substr(digit,1,2))|| '' \0623\0644\0641 \0648 ''|| spell(substr(digit,3)); '),
'ELSE ',
'  v_spell:= null; ',
'  END CASE; ',
'  RETURN v_spell; ',
' ',
'END SPELL_FIVE_DIGIT; ',
' ',
'FUNCTION SPELL_SIX_DIGIT(digit NUMBER) RETURN VARCHAR2 ',
'IS ',
'  v_spell varchar2(100); ',
'BEGIN ',
'  CASE ',
'   WHEN SUBSTR(digit,4) = 000 THEN ',
unistr('    RETURN spell_three_digit(substr(digit,1,3))||'' \0623\0644\0641 ''; '),
'   WHEN digit BETWEEN 100000 AND 999999 THEN ',
unistr('    v_spell:=spell_three_digit(substr(digit,1,3))||'' \0623\0644\0641 \0648 ''|| spell(substr(digit,4)); '),
'ELSE ',
'  v_spell:= null; ',
'  END CASE; ',
'  RETURN v_spell; ',
' ',
'END SPELL_SIX_DIGIT; ',
' ',
'FUNCTION SPELL_MILOEN_DIGIT(digit NUMBER) RETURN VARCHAR2 ',
'IS ',
'   v_spell varchar2(100); ',
'BEGIN ',
'CASE ',
'  WHEN digit IN(1000000,2000000,3000000,4000000,5000000,6000000,7000000,8000000,9000000)THEN ',
unistr('     RETURN spell_one_digit(substr(digit,1,1))||'' \0645\0644\064A\0648\0646 ''; '),
'  WHEN digit BETWEEN 1000000 AND 9999999 THEN ',
unistr('     v_spell:= spell_one_digit(substr(digit,1,1))||'' \0645\0644\064A\0648\0646 \0648 ''|| spell(substr(digit,2)); '),
'  WHEN digit IN(10000000,20000000,30000000,40000000,50000000,60000000,70000000,80000000,90000000) THEN ',
unistr('     RETURN spell_two_digit(substr(digit,1,2))||'' \0645\0644\064A\0648\0646 ''; '),
'  WHEN digit BETWEEN 10000000 AND 99999999 THEN ',
unistr('      v_spell := spell_two_digit(substr(digit,1,2))||'' \0645\0644\064A\0648\0646 \0648 ''|| spell(substr(digit,3)); '),
'  ELSE ',
'   v_spell:= null; ',
'  END CASE; ',
'  RETURN v_spell; ',
' ',
'END SPELL_MILOEN_DIGIT; ',
' ',
'FUNCTION SPELL_MONEY(v_money_in number) RETURN VARCHAR2 ',
'IS ',
unistr('   currency_name1 varchar2(30):= '' \062C\0646\064A\0647 ''; -- EX:dollar '),
unistr('   currency_name2  varchar2(30):= '' \0642\0631\0634 '';-- EX:Cent '),
'   v_money number; ',
'   num_before_period number; ',
'   num_after_period  number; ',
'   period_pos number;-- Period Location ',
'   the_and varchar2(3);-- the And ',
'   cur_name1 varchar2(30); ',
'   cur_name2 varchar2(30); ',
'   v_only varchar2(7); ',
'   no_else varchar2(10); ',
' ',
'BEGIN ',
' ',
'-- get the parameter pass for EXample:(123.60) ',
'    v_money:= v_money_in; ',
'-- get the number before period = 123 ',
'    num_before_period := trunc(v_money); ',
'-- get the number after period = 60 ',
'    num_after_period := (v_money-trunc(v_money))*100; ',
'-- get the position of period = 4 ',
'    period_pos := instr(v_money,''.''); ',
'IF num_before_period = 0 THEN ',
'	cur_name1 := null; ',
'	v_only := null; ',
'	no_else := null; ',
'	the_and := NULL; ',
'ELSE ',
'	cur_name1 := currency_name1; ',
unistr('	v_only := '' \0641\0642\0637 ''; '),
unistr('	no_else := ''\0644\0627\063A\064A\0631''; '),
'END IF; ',
' ',
' IF period_pos = 0 THEN ',
' ',
'   the_and := null; ',
'   cur_name2 := null; ',
' ',
' ELSE ',
'     IF num_before_period <> 0 THEN ',
unistr('      the_and := ''\0648''; '),
'     END IF; ',
' ',
'   cur_name2 := currency_name2; ',
unistr('    no_else := ''\0644\0627\063A\064A\0631''; '),
unistr('    v_only := '' \0641\0642\0637 ''; '),
' ',
'END IF; ',
' ',
'  RETURN v_only||spell(num_before_period)||cur_name1||the_and||spell(num_after_period)||cur_name2||no_else; ',
' ',
'END SPELL_MONEY; ',
' ',
'END SPELL_NUMBER; ',
'/',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
''))
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380193259015259176)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'TAFQEET'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380193303863259178)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'BOX_BOX_C_PK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380193564465259178)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'BOX_CON'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380193714200259178)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'CLASS_PK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380193897173259178)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'COMPANY_COMP_C_PK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380194172984259178)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'DEALERS_PK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380194286589259178)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EMPLOYEE_CON'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380194495566259178)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'FACTORY_FACTOR_C_PK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380194719858259178)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'INVOICE_PK11'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380194932516259178)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'INV_DETAIL_PK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380195102025259179)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'ITEM_STORE_PK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380195358763259179)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'STORE_STORE_NO_PK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380195511728259179)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'USERS_USER_C_PK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380195768357259179)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'SPELL_NUMBER'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380195928830259180)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PROCEDURE'
,p_object_name=>'CONSTRAINTS_MAKER'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380196155755259180)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PROCEDURE'
,p_object_name=>'FK_CONSTRAINT_MAKER'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380196314647259180)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PROCEDURE'
,p_object_name=>'INSERT_STORE_SANF'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380196490244259180)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'BOX_SEQ'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380196715777259180)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'CLASS_SE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380196937823259180)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'CLASS_SEQ'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380197165758259181)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'DEALER_C_N'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380197363878259181)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'EMPNO_SE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380197491877259181)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'INVNO_C_SE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380197761773259181)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'ITEM_C_SE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380197887135259181)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'SANF_CARD_SEQ'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380198144798259181)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'SEO_SE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380198384213259181)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'UNIT_C_N'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380198545745259181)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'BANK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380198717691259181)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'BOX'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380198928933259181)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'BOX_OLD'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380199090006259182)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'CHECK_TYPE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380199381335259182)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'CLASS'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380199500964259182)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'COMPANY'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380199761780259182)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DEALERS'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380199979298259182)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DEPT'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380200106016259182)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'DOC_TYPE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380200357026259182)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EMPLOYEE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380200494238259182)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'FACTORY'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380200778842259183)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'HTMLDB_PLAN_TABLE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380200911228259183)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'INVOICE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380201098546259183)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'INV_DETAIL'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380201372126259183)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ITEMS'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380201533241259183)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ITEM_CARD'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380201739793259183)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'ORG'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380201887188259183)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'PAY_WAY'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380202152487259183)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'SANF'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380202311802259183)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'SANF_CARD'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380202536464259183)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'STORE'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380202753493259184)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'UNITS'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380202970715259184)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'USERS'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380203118242259184)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BI_CLASS'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380203363262259184)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BOX_t'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380203555590259184)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'DECLEAR_NO'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380203774427259184)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'INVOICE_C_NO'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380203983715259184)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'INV_DETAIL_seq'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380204091203259184)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'ITEM_C_NO'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380204303724259184)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'T_CUST'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380204516116259184)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'T_DEALERS'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380204763070259185)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'T_ITEM_STORE2'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380204894631259185)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'T_UP_BOX_DEALERS'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380205173375259185)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'T_UP_INVOICE_DEALERS'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380205294976259185)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'UNITS_NO'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380205582609259185)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'UP_CUST_BAL'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380205720189259185)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'UP_CUST_NEW'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380205931407259185)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'employeeid_t'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380206128746259185)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'BUYER_QTY'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380206338674259185)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'BUYER_QTY_BACK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380206495071259186)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'CUST_ACC'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380206718862259186)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'CUST_DETIAL'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380206912133259186)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'ITEM_TRANS'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380207149799259186)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'SELL_QTY'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380207292851259186)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'SELL_QTY_BACK'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380207492032259186)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'SUPP_ACC'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(39380207687491259190)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'SUPP_DETIAL'
,p_last_updated_by=>'ADMIN'
,p_last_updated_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
,p_created_by=>'ADMIN'
,p_created_on=>to_date('20230714105153','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(75035957438998554690)
,p_script_id=>wwv_flow_imp.id(39380193110247259161)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'AUTHENTICATE_USER'
,p_last_updated_by=>'ELWMO2005@GMAIL.COM'
,p_last_updated_on=>to_date('20231005161430','YYYYMMDDHH24MISS')
,p_created_by=>'ELWMO2005@GMAIL.COM'
,p_created_on=>to_date('20231005161430','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
