prompt --application/shared_components/logic/application_computations/a07
begin
--   Manifest
--     APPLICATION COMPUTATION: A07
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(39371960860744347195)
,p_computation_sequence=>10
,p_computation_item=>'A07'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'select count(*) from INVOICE where INV_TYPE=2'
);
wwv_flow_imp.component_end;
end;
/
