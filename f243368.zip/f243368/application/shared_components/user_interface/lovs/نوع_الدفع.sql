prompt --application/shared_components/user_interface/lovs/نوع_الدفع
begin
--   Manifest
--     نوع الدفع
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(39372819712499778619)
,p_lov_name=>unistr('\0646\0648\0639 \0627\0644\062F\0641\0639')
,p_lov_query=>'.'||wwv_flow_imp.id(39372819712499778619)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(39372820089297778619)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('\0646\0642\062F\064A')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(39372820480928778619)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('\0634\064A\0643')
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
