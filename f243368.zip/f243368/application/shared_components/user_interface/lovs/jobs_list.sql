prompt --application/shared_components/user_interface/lovs/jobs_list
begin
--   Manifest
--     JOBS_LIST
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(39372094398182853211)
,p_lov_name=>'JOBS_LIST'
,p_lov_query=>'.'||wwv_flow_imp.id(39372094398182853211)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(39372094705098853212)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('\0645\0633\0626\0648\0644 \0645\062E\0627\0632\0646')
,p_lov_return_value=>unistr('\0645\0633\0626\0648\0644 \0645\062E\0627\0632\0646')
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(39372095022621853219)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('\0645\0633\0626\0648\0644 \0645\0634\062A\0631\064A\0627\062A')
,p_lov_return_value=>unistr('\0645\0633\0626\0648\0644 \0645\0634\062A\0631\064A\0627\062A')
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(39372095443009853219)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>unistr('\0645\0633\0626\0648\0644 \062D\0633\0627\0628\0627\062A')
,p_lov_return_value=>unistr('\0645\0633\0626\0648\0644 \062D\0633\0627\0628\0627\062A')
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(39372095842946853219)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('\0645\062F\064A\0631 \0627\0644\0628\0631\0646\0627\0645\062C')
,p_lov_return_value=>unistr('\0645\062F\064A\0631 \0627\0644\0628\0631\0646\0627\0645\062C')
);
wwv_flow_imp.component_end;
end;
/
