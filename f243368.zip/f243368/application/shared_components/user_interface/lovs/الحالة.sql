prompt --application/shared_components/user_interface/lovs/الحالة
begin
--   Manifest
--     الحالة
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(48574144665361909606)
,p_lov_name=>unistr('\0627\0644\062D\0627\0644\0629')
,p_lov_query=>'.'||wwv_flow_imp.id(48574144665361909606)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(48574144982539909607)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('\0645\0641\0639\0644')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(48574145300567909607)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('\063A\064A\0631 \0645\0641\0639\0644')
,p_lov_return_value=>'0'
);
wwv_flow_imp.component_end;
end;
/
