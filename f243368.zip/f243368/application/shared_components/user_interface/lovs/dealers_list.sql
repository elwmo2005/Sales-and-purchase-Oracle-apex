prompt --application/shared_components/user_interface/lovs/dealers_list
begin
--   Manifest
--     DEALERS_LIST
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(39372901101913224535)
,p_lov_name=>'DEALERS_LIST'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DEALER_N as d,',
'       DEALER_C as r',
'  from DEALERS',
' order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
