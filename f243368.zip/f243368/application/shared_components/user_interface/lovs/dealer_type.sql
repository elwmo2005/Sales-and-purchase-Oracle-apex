prompt --application/shared_components/user_interface/lovs/dealer_type
begin
--   Manifest
--     DEALER_TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(39372901326177233945)
,p_lov_name=>'DEALER_TYPE'
,p_lov_query=>'.'||wwv_flow_imp.id(39372901326177233945)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(39372901668340233950)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('\0645\0640\0640\0648\0631\062F')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(39372902093939233954)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('\0639\0640\0645\064A\0644')
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
