prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(39371678793645209311)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39371817083542209556)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('\0627\0644\0635\0641\062D\0629 \0627\0644\0631\0626\064A\0633\064A\0629')
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39371830575499245579)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('\0627\0644\0628\064A\0627\0646\0627\062A \0627\0644\0627\0633\0627\0633\064A\0629')
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39371852514856280804)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>unistr('\0628\064A\0627\0646\0627\062A \0627\0644\0640\0645\0624\0633\0640\0640\0633\0629')
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-building'
,p_parent_list_item_id=>wwv_flow_imp.id(39371830575499245579)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39371920611939339111)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>unistr('\0628\064A\0627\0646\0627\062A \0645\062D\0632\0646 \0627\0644\0645\0646\0634\0623\0647')
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-list-alt'
,p_parent_list_item_id=>wwv_flow_imp.id(39371830575499245579)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4,5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39371957414484572296)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>unistr('\0628\064A\0627\0646\0627\062A \0627\0644\0645\0648\0631\062F\064A\0646 [&A01.]')
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-arrow-down'
,p_parent_list_item_id=>wwv_flow_imp.id(39371830575499245579)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6,7,6'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372035027940604580)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>unistr('\0628\064A\0627\0646\0627\062A \0627\0644\0639\0645\0644\0627\0621 [&A02.]')
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users'
,p_parent_list_item_id=>wwv_flow_imp.id(39371830575499245579)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372088443023783534)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>unistr('\0628\064A\0627\0646\0627\062A \0645\0648\0638\0641\064A\0646')
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-headset'
,p_parent_list_item_id=>wwv_flow_imp.id(39371830575499245579)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10,11'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372106998576058892)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>unistr('\0645\062C\0645\0648\0639\0627\062A \0627\0644\0627\0635\0646\0627\0641')
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-braille'
,p_parent_list_item_id=>wwv_flow_imp.id(39371830575499245579)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372119191371240934)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>unistr('\0648\062D\062F\0627\062A \0627\0644\0642\064A\0627\0633')
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-window-terminal'
,p_parent_list_item_id=>wwv_flow_imp.id(39371830575499245579)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372145205659293243)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>unistr('\0628\064A\0627\0646\0627\062A \0627\0644\0627\0635\0646\0627\0641 [&A03.]')
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-folder-plus'
,p_parent_list_item_id=>wwv_flow_imp.id(39371830575499245579)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14,15'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372168056872899104)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>unistr('\062A\0639\0631\064A\0641 \0627\0644\0627\0635\0646\0627\0641 \0639\0644\0649 \0627\0644\0645\062E\0632\0646')
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-battery-4'
,p_parent_list_item_id=>wwv_flow_imp.id(39371830575499245579)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372181899657497597)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>unistr('\062D\0631\0643\0629 \0627\0644\0628\064A\0639 \0648 \0627\0644\0634\0631\0627\0621')
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cart-full'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372291555877552495)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>unistr('\0627\0644\0645\0634\062A\0631\064A\0627\062A [&A04.]')
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cart-arrow-down'
,p_parent_list_item_id=>wwv_flow_imp.id(39372181899657497597)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'17,18'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372513900309296406)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>unistr(' \0645\0631\062A\062C\0639\0627\062A \0645\0634\062A\0631\064A\0627\062A [&A06.]')
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cart-arrow-up'
,p_parent_list_item_id=>wwv_flow_imp.id(39372181899657497597)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'19,20'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372585090045997073)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>unistr('\0627\0644\0645\0628\064A\0639\0627\062A [&A05.]')
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cart-check'
,p_parent_list_item_id=>wwv_flow_imp.id(39372181899657497597)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'21'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372622669897538820)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>unistr('\0645\0631\062A\062C\0639\0627\062A \0627\0644\0645\0628\064A\0639\0627\062A [&A07.]')
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cart-times'
,p_parent_list_item_id=>wwv_flow_imp.id(39372181899657497597)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'23'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372688517322146692)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>unistr('\0627\0644\062E\0632\064A\0646\0629')
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dollar'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372714213051165247)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>unistr('\0627\0644\062E\0632\064A\0646\0629 \0645\0639 \0645\0648\0631\062F\064A\0646')
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-arrow-down'
,p_parent_list_item_id=>wwv_flow_imp.id(39372688517322146692)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'25,26'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372828696039833308)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>unistr('\0627\0644\062E\0632\064A\0646\0629 \0645\0639 \0627\0644\0639\0645\0644\0627\0621')
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-arrow-up'
,p_parent_list_item_id=>wwv_flow_imp.id(39372688517322146692)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'27'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372859566052901282)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>unistr('\0627\0644\0645\062E\0627\0632\0646')
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-server-chart'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39373660959536646934)
,p_list_item_display_sequence=>201
,p_list_item_link_text=>unistr('\0631\0635\064A\062F \0627\0641\062A\062A\0627\062D\064A')
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_parent_list_item_id=>wwv_flow_imp.id(39372859566052901282)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'31'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372859919988911493)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>unistr('\0627\0631\0635\062F\0629 \0627\0644\0645\062E\0627\0632\0646')
,p_list_item_link_target=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clipboard-list'
,p_parent_list_item_id=>wwv_flow_imp.id(39372859566052901282)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'29'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39372882613601079454)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>unistr('\062D\0631\0643\0629 \0627\0644\0635\0646\0641')
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-exchange'
,p_parent_list_item_id=>wwv_flow_imp.id(39372859566052901282)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'30'
);
wwv_flow_imp.component_end;
end;
/
