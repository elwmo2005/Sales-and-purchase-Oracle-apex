prompt --application/pages/page_00034
begin
--   Manifest
--     PAGE: 00034
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page(
 p_id=>34
,p_name=>unistr('\062A\0641\0627\0635\064A\0644 \0641\0627\062A\0648\0631\0629')
,p_step_title=>unistr('\062A\0641\0627\0635\064A\0644 \0641\0627\062A\0648\0631\0629')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'var htmldb_ch_message=''"OK_TO_GET_NEXT_PREV_PK_VALUE"'';',
'// create a private scope where $ is set to apex.jQuery',
'(function($) {',
'    // This is the function that calculates over all the rows of the model and then',
'    // updates something else.',
'    // Change this to do whatever calculation is needed.',
'    // Call this whenever the model data changes.',
'    function update(model) {',
'        var salKey = model.getFieldKey("ITEM_VAL"), ',
'            total = 0;',
'',
'        console.log(">> starting sum SAL column")',
'        model.forEach(function(record, index, id) {',
'            var sal = parseFloat(record[salKey]),  // record[salKey] should be a little faster than using model.getValue in a loop',
'                meta = model.getRecordMetadata(id);',
'',
'            if (!isNaN(sal) && !meta.deleted && !meta.agg) {',
'                total += sal;',
'            }',
'        });',
'        console.log(">> setting sum SAL column to " + total)',
'        $s("P34_INV_NET", total);',
'    }',
'',
'    //',
'    // This is the general pattern for subscribing to model notifications',
'    //',
'',
'    // need to do this here rather than in Execute when Page Loads so that the handler',
'    // is setup BEFORE the IG is initialized otherwise miss the first model created event',
'    $(function() {',
'        // the model gets released and created at various times such as when the report changes',
'        // listen for model created events so that we can subscribe to model notifications',
'        $("#inv_details").on("interactivegridviewmodelcreate", function(event, ui) {',
'            var sid,',
'                model = ui.model;',
'',
'            // note this is only done for the grid veiw. It could be done for',
'            // other views if desired. The imporant thing to realize is that each',
'            // view has its own model',
'            if ( ui.viewId === "grid" ) {',
'                sid = model.subscribe( {',
'                    onChange: function(type, change) {',
'                        console.log(">> model changed ", type, change);',
'                        if ( type === "set" ) {',
'                            // don''t bother to recalculate if other columns change',
'                            if (change.field === "ITEM_VAL" ) {',
'                                update( model );',
'                            }',
'                        } else if (type !== "move" && type !== "metaChange") {',
'                            // any other change except for move and metaChange affect the calculation',
'                            update( model );',
'                        }',
'                    },',
'                    progressView: $("#P34_INV_NET") // this will cause a spinner on this field',
'                } );',
'                // if not lazy loaded there is no notification for initial data so update',
'                update( model ); ',
'                // just in case fetch all the data. Model notifications will',
'                // cause calls to update so nothing to do in the callback function.',
'                // can remove if data will always be less than 50 records',
'                model.fetchAll(function() {});',
'            }',
'        });',
'',
'    });',
'',
'})(apex.jQuery);',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'ELWMO2005@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231005161047'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39367470886969615473)
,p_plug_name=>unistr('\0641\0627\062A\0648\0631\0629 \0628\064A\0639')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(39371728561624209381)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39367492533175615664)
,p_plug_name=>unistr('\062A\0641\0627\0635\064A\0644 \0641\0627\062A\0648\0631\0629')
,p_region_name=>'inv_details'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39371727424569209381)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select INV_NO,',
'       INV_DATE,',
'       INV_TYPE,',
'       STORE_NO,',
'       DEALER_C,',
'       DEALER_TYPE,',
'       ITEM_C,',
'       QTY,',
'       PRICE,',
'       ITEM_VAL,',
'       UOM,',
'       UP_DATE,',
'       COMP_C,',
'       PAY_TYPE,',
'       BAL_AFTER,',
'       I_SEQ,',
'       CH_STORE_C,',
'       NOTES,',
'       EMP_ID,',
'       CLASS_C,',
'       SEO',
'  from INV_DETAIL',
' where INV_NO = :P34_INV_NO'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P34_INV_NO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367493703060615675)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367494242039615678)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>'Actions'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367494832240615682)
,p_name=>'INV_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INV_NO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P34_INV_NO'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367495445345615682)
,p_name=>'INV_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INV_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P34_INV_DATE'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367496015255615683)
,p_name=>'INV_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INV_TYPE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P34_INV_TYPE'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367496600752615684)
,p_name=>'STORE_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STORE_NO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P34_STORE_NO'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367497260481615684)
,p_name=>'DEALER_C'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DEALER_C'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P34_DEALER_C'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367497872816615684)
,p_name=>'DEALER_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DEALER_TYPE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'2'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367498438147615685)
,p_name=>'ITEM_C'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM_C'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>unistr('\0627\0644\0635\0646\0641')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ITEM_N as d,',
'       ITEM_C as r',
'  from SANF',
'where CLASS_C=:CLASS_C',
' order by 1'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_cascade_parent_items=>'CLASS_C'
,p_ajax_items_to_submit=>'ITEM_C'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367499087279615685)
,p_name=>'QTY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('\0627\0644\0643\0645\064A\0629')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'CENTER'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367499672017615685)
,p_name=>'PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRICE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('\0627\0644\0633\0639\0631')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'CENTER'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367500234290615686)
,p_name=>'ITEM_VAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM_VAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('\0627\0644\0642\064A\0645\0629')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'CENTER'
,p_attribute_03=>'center'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367500882762615688)
,p_name=>'UOM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UOM'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367501490477615689)
,p_name=>'UP_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UP_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367502024230615690)
,p_name=>'COMP_C'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMP_C'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367502688170615690)
,p_name=>'PAY_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAY_TYPE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>170
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367503285465615690)
,p_name=>'BAL_AFTER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BAL_AFTER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>180
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367503844864615691)
,p_name=>'I_SEQ'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'I_SEQ'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367504411305615691)
,p_name=>'CH_STORE_C'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CH_STORE_C'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>200
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367505004679615691)
,p_name=>'NOTES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NOTES'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>210
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367505604485615692)
,p_name=>'EMP_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMP_ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367506286203615692)
,p_name=>'CLASS_C'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CLASS_C'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>unistr('\0627\0644\0645\062C\0645\0648\0639\0629 \0627\0644\0635\0646\0641\064A\0629')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(39372163491765273891)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39367506846500615692)
,p_name=>'SEO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>230
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(39367493050447615669)
,p_internal_uid=>14328057640570396
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(39367493472856615673)
,p_interactive_grid_id=>wwv_flow_imp.id(39367493050447615669)
,p_static_id=>'393514610'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(39367493521757615674)
,p_report_id=>wwv_flow_imp.id(39367493472856615673)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367494689964615678)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(39367494242039615678)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367495252505615682)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(39367494832240615682)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367495877679615683)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(39367495445345615682)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367496427842615684)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(39367496015255615683)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367497035846615684)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(39367496600752615684)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367497671435615684)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(39367497260481615684)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367498272715615685)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(39367497872816615684)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367498886872615685)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(39367498438147615685)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367499395365615685)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(39367499087279615685)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367500014986615686)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(39367499672017615685)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367500651504615688)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(39367500234290615686)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367501275145615688)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(39367500882762615688)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367501809989615689)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(39367501490477615689)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367502409999615690)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(39367502024230615690)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367503036210615690)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(39367502688170615690)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367503661419615690)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(39367503285465615690)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367504252392615691)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(39367503844864615691)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367504854433615691)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(39367504411305615691)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367505491403615692)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(39367505004679615691)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367506005483615692)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(39367505604485615692)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367506626689615692)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(39367506286203615692)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39367507124427615693)
,p_view_id=>wwv_flow_imp.id(39367493521757615674)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(39367506846500615692)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367471305251615481)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\062D\0641\0638 \0627\0644\062A\063A\064A\0631\0627\062A')
,p_button_position=>'CHANGE'
,p_button_condition=>'P34_INV_NO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367488968684615636)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_button_name=>'GET_PREVIOUS_INV_NO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371783994102209437)
,p_button_image_alt=>'Previous'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P34_INV_NO_PREV'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-chevron-left'
,p_button_comment=>'This button is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367488876986615636)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_button_name=>'GET_NEXT_INV_NO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371783994102209437)
,p_button_image_alt=>'Next'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P34_INV_NO_NEXT'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-chevron-right'
,p_button_comment=>'This button is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367471567864615481)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_image_alt=>unistr('\0627\0644\0631\062C\0648\0639')
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367471216717615481)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\062D\0641\0638 \0641\0627\062A\0648\0631\0629')
,p_button_position=>'CREATE'
,p_button_condition=>'P34_INV_NO'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367471457693615481)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_image_alt=>unistr('\062D\0630\0641 \0641\0627\062A\0648\0631\0629')
,p_button_position=>'DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P34_INV_NO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39371962754771372709)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_button_name=>'print'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371783994102209437)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Print'
,p_button_position=>'HELP'
,p_button_redirect_url=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:RP,34:P36_INV_NO:&P34_INV_NO.'
,p_button_condition=>'P34_INV_NO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-print'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(39364293743103003395)
,p_branch_name=>'stay_after'
,p_branch_action=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:RP:P34_INV_NO:&P34_INV_NO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(39364293802477003396)
,p_branch_name=>'direction_brachong'
,p_branch_action=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:RP:P34_INV_NO:&P34_INV_NO_NEXT.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(39367488876986615636)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(39364293964264003397)
,p_branch_name=>'direction_brachong'
,p_branch_action=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:RP:P34_INV_NO:&P34_INV_NO_PREV.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(39367488968684615636)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367473405832615530)
,p_name=>'P34_INV_NO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Inv No'
,p_source=>'INV_NO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367473888629615550)
,p_name=>'P34_INV_DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\062A\0627\0631\064A\062E \0627\0644\0641\0627\062A\0648\0631\0629')
,p_source=>'INV_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367474251532615557)
,p_name=>'P34_INV_TYPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_item_default=>'3'
,p_source=>'INV_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367474624177615557)
,p_name=>'P34_STORE_NO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\0627\0644\0645\062E\0632\0646')
,p_source=>'STORE_NO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'STORE_LIST'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367475059062615557)
,p_name=>'P34_DEALER_C'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\0627\0644\0639\0645\064A\0644')
,p_source=>'DEALER_C'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CUSTOMERS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DEALER_N as d,',
'       DEALER_C as r',
'  from DEALERS',
'where DEALER_TYPE =2	',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367475489702615558)
,p_name=>'P34_DEALER_TYPE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_item_default=>'2'
,p_source=>'DEALER_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367475824534615558)
,p_name=>'P34_NOTE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\0645\0644\0627\062D\0638\0627\062A')
,p_source=>'NOTE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367476258738615558)
,p_name=>'P34_INV_DIS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_source=>'INV_DIS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367476637661615558)
,p_name=>'P34_INV_NET'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\0627\062C\0645\0627\0644\064A \0627\0644\0641\0627\062A\0648\0631\0629')
,p_source=>'INV_NET'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'center'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367477027937615558)
,p_name=>'P34_UP_DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_source=>'UP_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367477434717615559)
,p_name=>'P34_USER_C'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_source=>'USER_C'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367477801540615559)
,p_name=>'P34_COMP_C'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_source=>'COMP_C'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367478228901615559)
,p_name=>'P34_PAY_TYPE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_source=>'PAY_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367478622633615559)
,p_name=>'P34_CH_STORE_C'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_source=>'CH_STORE_C'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367479045191615560)
,p_name=>'P34_EMP_ID'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_use_cache_before_default=>'NO'
,p_source=>'EMP_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367489617269615643)
,p_name=>'P34_INV_NO_NEXT'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_prompt=>'P34_INV_NO_NEXT'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_item_comment=>'This item is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367490010984615643)
,p_name=>'P34_INV_NO_PREV'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_prompt=>'P34_INV_NO_PREV'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_item_comment=>'This item is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367490442949615645)
,p_name=>'P34_INV_NO_COUNT'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(39367470886969615473)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cSize=>30
,p_tag_attributes=>'class="fielddata"'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
,p_item_comment=>'This item is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39364294189292003399)
,p_name=>'get_item_price'
,p_event_sequence=>10
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(39367492533175615664)
,p_triggering_element=>'ITEM_C'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39364294230418003400)
,p_event_id=>wwv_flow_imp.id(39364294189292003399)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'PRICE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SANF.SALE_PRICE as SALE_PRICE',
' from SANF SANF',
'where ITEM_C =:ITEM_C '))
,p_attribute_07=>'ITEM_C'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39364294348274003401)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(39367492533175615664)
,p_triggering_element=>'QTY,PRICE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39364294491992003402)
,p_event_id=>wwv_flow_imp.id(39364294348274003401)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'ITEM_VAL'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':qty * :price'
,p_attribute_07=>'QTY,PRICE'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367479830242615561)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from INVOICE'
,p_attribute_02=>'INVOICE'
,p_attribute_03=>'P34_INV_NO'
,p_attribute_04=>'INV_NO'
,p_internal_uid=>39367479830242615561
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367491446891615651)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_PAGINATION'
,p_process_name=>'Get Next or Previous Primary Key Value'
,p_attribute_02=>'INVOICE'
,p_attribute_03=>'P34_INV_NO'
,p_attribute_04=>'INV_NO'
,p_attribute_07=>'INV_NO'
,p_attribute_09=>'P34_INV_NO_NEXT'
,p_attribute_10=>'P34_INV_NO_PREV'
,p_attribute_13=>'P34_INV_NO_COUNT'
,p_internal_uid=>39367491446891615651
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367480287185615561)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of INVOICE'
,p_attribute_02=>'INVOICE'
,p_attribute_03=>'P34_INV_NO'
,p_attribute_04=>'INV_NO'
,p_attribute_09=>'P34_INV_NO'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>39367480287185615561
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367507383353615693)
,p_process_sequence=>35
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(39367492533175615664)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('\062A\0641\0627\0635\064A\0644 \0641\0627\062A\0648\0631\0629 - Save Interactive Grid Data')
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    case :APEX$ROW_STATUS',
'    when ''C'' then',
'        insert into INV_DETAIL ( seo, inv_no, inv_date,inv_type,class_c,item_c,qty,price,item_val,store_no,dealer_c ,dealer_type)',
'        values ( :seo, :P34_INV_NO,:P34_INV_DATE,:P34_INV_TYPE,:class_c,:item_c,:qty,:price,:item_val,:P34_STORE_NO,:P34_DEALER_C,:P34_DEALER_type )',
'        returning seo into :seo ;',
'    when ''U'' then',
'        update INV_DETAIL',
'           set  inv_date= :ENAME,',
'               class_c= :class_c,',
'              item_c=:item_c,',
'             qty=:qty,',
'             price=:price,',
'            item_val=:item_val,',
'            store_no=:P34_STORE_NO,',
'            DEALER_C=:P34_DEALER_C,',
'            DEALER_type=:P34_DEALER_type',
'         where seo = :seo ;',
'    when ''D'' then',
'        delete INV_DETAIL',
'         where seo = :seo ;',
'    end case;',
'end;',
''))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>39367507383353615693
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39364294581702003403)
,p_process_sequence=>45
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'update|_total'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update INVOICE',
'set INV_NET=(select sum(ITEM_VAL) from INV_DETAIL',
'where INV_NO=:P34_INV_NO)',
'where INV_NO=:P34_INV_NO;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>39364294581702003403
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367480644042615561)
,p_process_sequence=>55
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39367471457693615481)
,p_internal_uid=>39367480644042615561
);
wwv_flow_imp.component_end;
end;
/
