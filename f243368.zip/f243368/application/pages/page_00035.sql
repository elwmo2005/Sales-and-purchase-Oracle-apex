prompt --application/pages/page_00035
begin
--   Manifest
--     PAGE: 00035
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page(
 p_id=>35
,p_name=>unistr('\0637\0628\0627\0639\0629 \0641\0627\062A\0648\0631\0629 \0634\0631\0627\0621')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\0637\0628\0627\0639\0629 \0641\0627\062A\0648\0631\0629 \0634\0631\0627\0621')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'       ',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'10'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230304171941'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39364294816304003406)
,p_plug_name=>'print inv'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39371703396522209369)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Declare',
'V_INV_DATE DATE;',
'V_STORE_NO NUMBER;',
'V_DEALER_N VARCHAR2(200);',
'V_INV_NET NUMBER;',
'',
'cursor s_details is',
'select CLASS.CLASS_N as CLASS_N,',
'    SANF.ITEM_N as ITEM_N,',
'    INV_DETAIL.QTY as QTY,',
'    INV_DETAIL.PRICE as PRICE,',
'    INV_DETAIL.ITEM_VAL as ITEM_VAL ',
' from CLASS ,',
'    SANF ,',
'    INV_DETAIL ',
' where CLASS.CLASS_C=INV_DETAIL.CLASS_C',
'    and SANF.ITEM_C=INV_DETAIL.ITEM_C',
'and INV_DETAIL.INV_NO=:P35_INV_NO;',
'',
'begin',
'select INVOICE.INV_DATE as INV_DATE,',
'    INVOICE.STORE_NO as STORE_NO,',
'    DEALERS.DEALER_N as DEALER_N,',
'    INVOICE.INV_NET  AS INV_NET',
' into V_INV_DATE,V_STORE_NO ,V_DEALER_N ,V_INV_NET ',
'FROM INVOICE',
'left OUTER JOIN DEALERS ON INVOICE.DEALER_C = DEALERS.DEALER_C',
'WHERE INVOICE.INV_NO =:P35_INV_NO ;',
'htp.p(''',
'<table>',
'  <tr>',
unistr('    <th>\062A\0627\0631\064A\062E \0627\0644\0641\0627\062A\0648\0631\0629</th>'),
'     <td>''||V_INV_DATE||'' </td>',
'',
' <tr>',
unistr('    <th>\0627\0644\0645\062E\0632\0646</th>'),
'    <td>''||V_STORE_NO ||''</td>',
'</tr>',
'',
'  <tr>',
'   ',
unistr('      <th>\0627\0644\0645\0648\0631\062F</th>'),
'    <td>''||V_DEALER_N||'' </td>',
'  </tr>',
'</table>',
'',
'',
''');',
'htp.p('' <table>',
'        <tr>',
unistr('    <th>\0627\0644\0645\062C\0645\0648\0639\0629 \0627\0644\0635\0646\0641\064A\0629</th>'),
unistr('    <th>\0627\0644\0635\0646\0641</th>'),
unistr('    <th>\0627\0644\0643\0645\064A\0629 </th>'),
unistr('    <th>\0627\0644\0633\0639\0631</th>'),
unistr('    <th>\0627\0644\0642\064A\0645\0629</th>'),
'  </tr>'');',
'',
'FOR S1 IN s_details ',
'   LOOP',
'  htp.p(''',
'    <tr>',
'    <td>''||S1.CLASS_N||'' </td>',
'    <td>''||S1.ITEM_N||''</td>',
'    <td>''||S1.QTY||'' </td>',
'    <td>''||S1.PRICE||'' </td>',
'    <td>''||S1.ITEM_VAL||'' </td>',
'  </tr>',
''');',
' END LOOP;',
'',
'htp.p(''',
'</table>',
''');',
'htp.p(''<style>',
'table {',
'  font-family: arial, sans-serif;',
'  border-collapse: collapse;',
'  width: 100%;',
'}',
'',
'td, th {',
'  border: 1px solid #dddddd;',
'  text-align: center;',
'  padding: 8px;',
'}',
'',
'tr:nth-child(even) {',
'  background-color: #dddddd;',
'}',
'</style> ',
''');',
'',
'htp.p(''<br>'');',
'htp.p(''<br>'');',
'',
'htp.p(''',
'<table class="my-table">',
'  <tr>',
unistr('    <th> \0627\062C\0645\0627\0644\064A \0627\0644\0641\0627\062A\0648\0631\0629</th>'),
'  </tr>',
'  <tr>',
'    <td>''||V_INV_NET||'' </td>',
'  </tr>',
'</table>',
''');',
'',
'htp.p(''<style>',
'.my-table {',
'  border-collapse: collapse;',
'  width: 100%;',
'}',
'',
'.my-table th, .my-table td {',
'  padding: 12px 15px;',
'  text-align: left;',
'}',
'',
'.my-table th {',
'  background-color: #f2f2f2;',
'}</style>'');',
'',
'',
'',
'',
'',
'',
'',
'end;',
'',
''))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39364295376500003411)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(39364294816304003406)
,p_button_name=>'print_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_image_alt=>unistr('\0637\0628\0627\0639\0629')
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39364294898601003407)
,p_name=>'P35_INV_NO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(39364294816304003406)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39364295440141003412)
,p_name=>'print_clik'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(39364295376500003411)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39364295540387003413)
,p_event_id=>wwv_flow_imp.id(39364295440141003412)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window.print()',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
