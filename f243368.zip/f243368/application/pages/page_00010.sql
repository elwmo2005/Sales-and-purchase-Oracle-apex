prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>unistr('\0628\064A\0627\0646\0627\062A \0645\0648\0638\0641\064A\0646')
,p_step_title=>unistr('\0628\064A\0627\0646\0627\062A \0645\0648\0638\0641\064A\0646')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'ELWMO2005@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230715150916'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39372083952122783525)
,p_plug_name=>unistr('\0628\064A\0627\0646\0627\062A \0627\0644\0645\0648\0638\0641\064A\0646')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39371727424569209381)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select EMPLOYEE.EMP_ID as EMP_ID,',
'    EMPLOYEE.EMP_N as EMP_N,',
'    EMPLOYEE.ADDRESS as ADDRESS,',
'    EMPLOYEE.PHONE as PHONE,',
'    EMPLOYEE.MOBILE as MOBILE,',
'    EMPLOYEE.USER_C as USER_C,',
'    EMPLOYEE.UP_DATE as UP_DATE,',
'    EMPLOYEE.JOB as JOB,',
'    EMPLOYEE.DEPT_C as DEPT_C,',
'    EMPLOYEE.COMP_C as COMP_C ',
' from EMPLOYEE EMPLOYEE'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(39372084326230783525)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP:P11_EMP_ID:\#EMP_ID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ADMIN'
,p_internal_uid=>8209716114861041
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372084422950783527)
,p_db_column_name=>'EMP_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Emp Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372084859406783530)
,p_db_column_name=>'EMP_N'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>unistr('\0627\0633\0645 \0627\0644\0645\0648\0638\0641')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372085300154783530)
,p_db_column_name=>'ADDRESS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>unistr('\0627\0644\0639\0646\0648\0627\0646')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372085686611783531)
,p_db_column_name=>'PHONE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('\0627\0644\062A\0644\064A\0641\0648\0646')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372086023005783531)
,p_db_column_name=>'MOBILE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('\0627\0644\0645\0648\0628\064A\0644')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372086412046783531)
,p_db_column_name=>'USER_C'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'User C'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372086858638783532)
,p_db_column_name=>'UP_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Up Date'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372087251870783532)
,p_db_column_name=>'JOB'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>unistr('\0627\0644\0648\0638\064A\0641\0629')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372087708029783532)
,p_db_column_name=>'DEPT_C'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>unistr('\0627\0644\0642\0633\0645')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(39372094275000838980)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372088063207783532)
,p_db_column_name=>'COMP_C'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Comp C'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(39372099962423867214)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'82254'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EMP_ID:EMP_N:ADDRESS:PHONE:MOBILE:USER_C:UP_DATE:JOB:DEPT_C:COMP_C'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39372090123699783535)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(39372083952122783525)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\062C\062F\064A\062F')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:11'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39372089138751783534)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(39372083952122783525)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39372089628087783534)
,p_event_id=>wwv_flow_imp.id(39372089138751783534)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39372083952122783525)
);
wwv_flow_imp.component_end;
end;
/
