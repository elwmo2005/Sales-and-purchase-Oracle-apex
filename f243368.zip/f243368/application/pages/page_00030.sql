prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page(
 p_id=>30
,p_name=>unistr('\062D\0631\0643\0629 \0627\0644\0635\0646\0641')
,p_step_title=>unistr('\062D\0631\0643\0629 \0627\0644\0635\0646\0641')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230204132328'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39372883095446079466)
,p_plug_name=>unistr('\062D\0631\0643\0629 \0627\0644\0635\0646\0641')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39371727424569209381)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select INV_NO,',
'       INV_DATE,',
'       INV_TYPE,',
'       STORE_NO,',
'       ITEM_C,',
'       INCREASE,',
'       DECREASE,',
'       BALANCE,',
'       UOM,',
'       DEALER_C,',
'       DEALER_TYPE',
'  from ITEM_TRANS',
'  order by',
'  INV_DATE,INV_NO'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(39372883122018079466)
,p_name=>unistr('\062D\0631\0643\0629 \0627\0644\0635\0646\0641')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'ADMIN'
,p_internal_uid=>9008511902156982
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372883599177079513)
,p_db_column_name=>'INV_NO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Inv No'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372883826230079531)
,p_db_column_name=>'INV_DATE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>unistr('\062A\0627\0631\064A\062E \0627\0644\0641\0627\062A\0648\0631\0629')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'YYYY-MM-DD'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372884262554079531)
,p_db_column_name=>'INV_TYPE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>unistr('\0646\0648\0639 \0627\0644\062D\0631\0643\0629')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(39372900392364210334)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372884664367079532)
,p_db_column_name=>'STORE_NO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('\0627\0644\0645\062E\0632\0646')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(39372169753987951385)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372885019859079532)
,p_db_column_name=>'ITEM_C'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('\0627\0644\0635\0646\0641')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(39372871022431927592)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372885432622079532)
,p_db_column_name=>'INCREASE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>unistr('\0632\064A\0627\062F\0629')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372885830306079532)
,p_db_column_name=>'DECREASE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>unistr('\0633\062D\0628')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372886253676079535)
,p_db_column_name=>'BALANCE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>unistr('\0627\0644\0631\0635\064A\062F \0627\0644\062D\0627\0644\064A')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372886621261079536)
,p_db_column_name=>'UOM'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Uom'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372887100664079536)
,p_db_column_name=>'DEALER_C'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>unistr('\0627\0633\0645 \0627\0644\0645\062A\0639\0627\0645\0644')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(39372901101913224535)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372887452189079536)
,p_db_column_name=>'DEALER_TYPE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>unistr('\0645\0648\0631\062F / \0639\0645\064A\0644')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(39372901326177233945)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(39372892321661100057)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'90178'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'INV_NO:INV_DATE:INV_TYPE:STORE_NO:ITEM_C:INCREASE:DECREASE:BALANCE:UOM:DEALER_C:DEALER_TYPE:APXWS_CC_001'
,p_sum_columns_on_break=>'INCREASE:DECREASE:APXWS_CC_001'
);
wwv_flow_imp_page.create_worksheet_computation(
 p_id=>wwv_flow_imp.id(39373696585842809882)
,p_report_id=>wwv_flow_imp.id(39372892321661100057)
,p_db_column_name=>'APXWS_CC_001'
,p_column_identifier=>'C01'
,p_computation_expr=>'F - G'
,p_column_type=>'NUMBER'
,p_column_label=>unistr('\0627\0644\0631\0635\064A\062F \0646\0647\0627\0626\064A')
,p_report_label=>unistr('\0627\0644\0631\0635\064A\062F \0646\0647\0627\0626\064A')
);
wwv_flow_imp.component_end;
end;
/
