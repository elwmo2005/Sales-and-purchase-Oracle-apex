prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>unistr('\0628\064A\0627\0646\0627\062A \0627\0644\0645\0648\0631\062F\064A\0646')
,p_step_title=>unistr('\0628\064A\0627\0646\0627\062A \0627\0644\0645\0648\0631\062F\064A\0646')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230203171530'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39371988067438653358)
,p_plug_name=>unistr('\0628\064A\0627\0646\0627\062A \0627\0644\0645\0648\0631\062F\064A\0646')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39371727424569209381)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DEALER_C,',
'       DEALER_N,',
'       ADDRESS,',
'       PHONE,',
'       MOBILE,',
'       DEALER_TYPE,',
'       CONTACT_C,',
'       COMP_C,',
'       USER_C,',
'       SALES,',
'       SALES_RETURN,',
'       BUY,',
'       BUY_RETURN,',
'       DEALER_CREDIT,',
'       DEALER_CREDIT_BACK,',
'       CASH_IN,',
'       CASH_OUT,',
'       DIS_VAL,',
'       OPEN_BAL,',
'       BALANCE,',
'       UP_DATE',
'  from DEALERS',
'where  DEALER_TYPE=1'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(39371988432652653358)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RP:P7_DEALER_C:\#DEALER_C#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ADMIN'
,p_internal_uid=>8113822536730874
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371988517134653358)
,p_db_column_name=>'DEALER_C'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Dealer C'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371988935419653359)
,p_db_column_name=>'DEALER_N'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>unistr('\0627\0633\0645 \0627\0644\0645\0648\0631\062F')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371989372898653359)
,p_db_column_name=>'ADDRESS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>unistr('\0627\0644\0639\0640\0646\0648\0627\0646')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371989787684653359)
,p_db_column_name=>'PHONE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('\0627\0644\062A\0644\064A\0641\0648\0646')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371990118383653359)
,p_db_column_name=>'MOBILE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('\0627\0644\062C\0648\0627\0644')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371990583152653360)
,p_db_column_name=>'DEALER_TYPE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Dealer Type'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371990965393653360)
,p_db_column_name=>'CONTACT_C'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Contact C'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371991377716653360)
,p_db_column_name=>'COMP_C'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Comp C'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371991748321653360)
,p_db_column_name=>'USER_C'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'User C'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371992151579653360)
,p_db_column_name=>'SALES'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Sales'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371992531620653361)
,p_db_column_name=>'SALES_RETURN'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Sales Return'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371993006308653361)
,p_db_column_name=>'BUY'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>unistr('\0627\0644\0645\0634\062A\0631\064A\0627\062A')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371993361957653361)
,p_db_column_name=>'BUY_RETURN'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>unistr('\0645\0631\062F\0648\062F\0627\062A \0627\0644\0645\0634\062A\0631\064A\0627\062A')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371993809494653361)
,p_db_column_name=>'DEALER_CREDIT'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Dealer Credit'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371994121325653361)
,p_db_column_name=>'DEALER_CREDIT_BACK'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Dealer Credit Back'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371994569504653362)
,p_db_column_name=>'CASH_IN'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>unistr('\0645\0642\0628\0648\0636\0627\062A \0646\0642\062F\064A\0629')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371994985929653362)
,p_db_column_name=>'CASH_OUT'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>unistr('\0645\062F\0641\0648\0639\0627\062A \0646\0642\062F\064A\0629')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371995371650653362)
,p_db_column_name=>'DIS_VAL'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>unistr('\0627\062C\0645\0627\0644\064A \0627\0644\062E\0635\0645')
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371995726932653363)
,p_db_column_name=>'OPEN_BAL'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>unistr('\0627\0644\0631\0635\064A\062F \0627\0644\0627\0641\062A\0627\062D\064A\064A')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371996182007653363)
,p_db_column_name=>'BALANCE'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Balance'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39371996533178653363)
,p_db_column_name=>'UP_DATE'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Up Date'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(39371999377249654153)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'81248'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DEALER_C:DEALER_N:ADDRESS:PHONE:MOBILE:DEALER_TYPE:CONTACT_C:COMP_C:USER_C:SALES:SALES_RETURN:BUY:BUY_RETURN:DEALER_CREDIT:DEALER_CREDIT_BACK:CASH_IN:CASH_OUT:DIS_VAL:OPEN_BAL:BALANCE:UP_DATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39371998922292653366)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(39371988067438653358)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\062C\062F\064A\062F')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39371997931383653366)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(39371988067438653358)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39371998494915653366)
,p_event_id=>wwv_flow_imp.id(39371997931383653366)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39371988067438653358)
);
wwv_flow_imp.component_end;
end;
/
