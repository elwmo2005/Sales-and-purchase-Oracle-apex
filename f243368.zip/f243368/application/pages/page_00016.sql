prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>unistr('\062A\0639\0631\064A\0641 \0627\0644\0627\0635\0646\0627\0641 \0639\0644\0649 \0627\0644\0645\062E\0632\0646')
,p_page_mode=>'MODAL'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_last_updated_by=>'ELWMO2005@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230715151515'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39371264748041914830)
,p_plug_name=>unistr('\062A\0639\0631\064A\0641 \0627\0644\0627\0635\0646\0627\0641 \0639\0644\0649 \0627\0644\0645\062E\0632\0646')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(39371728561624209381)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39372170359481989185)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(39371264748041914830)
,p_button_name=>'btn_load'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\062A\062D\0645\064A\0644')
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-circle-down'
,p_grid_new_row=>'Y'
,p_grid_column_span=>5
,p_grid_column=>4
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39371265042681914833)
,p_name=>'P16_STORE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(39371264748041914830)
,p_prompt=>unistr('\0627\0644\0645\062E\0632\0646')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'STORE_LIST'
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('----------\0627\062E\062A\0631 \0627\0644\0645\062E\0632\0646-----------')
,p_cHeight=>1
,p_colspan=>5
,p_grid_column=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39372170469196989186)
,p_name=>'btn_load_action'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(39372170359481989185)
,p_condition_element=>'P16_STORE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39372170600693989187)
,p_event_id=>wwv_flow_imp.id(39372170469196989186)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'BEGIN',
'    INSERT_STORE_SANF(:P16_STORE);',
'END;',
'	 '))
,p_attribute_02=>'P16_STORE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39372170634532989188)
,p_event_id=>wwv_flow_imp.id(39372170469196989186)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('\062A\0645 \062A\0646\0632\064A\0644 \0627\0644\0627\0635\0646\0627\0641 \0639\0644\0649 \0627\0644\0645\062E\0632\0646')
);
wwv_flow_imp.component_end;
end;
/
