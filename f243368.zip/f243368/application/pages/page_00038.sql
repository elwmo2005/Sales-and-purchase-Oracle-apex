prompt --application/pages/page_00038
begin
--   Manifest
--     PAGE: 00038
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page(
 p_id=>38
,p_name=>unistr('\062A\0641\0627\0635\064A\0644 \0627\0644\0641\0627\062A\0648\0631\0629')
,p_step_title=>unistr('\062A\0641\0627\0635\064A\0644 \0627\0644\0641\0627\062A\0648\0631\0629')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'var htmldb_ch_message=''"OK_TO_GET_NEXT_PREV_PK_VALUE"'';',
'// create a private scope where $ is set to apex.jQuery',
'(function($) {',
'    // This is the function that calculates over all the rows of the model and then',
'    // updates something else.',
'    // Change this to do whatever calculation is needed.',
'    // Call this whenever the model data changes.',
'    function update(model) {',
'        var salKey = model.getFieldKey("ITEM_VAL"), ',
'            total = 0;',
'',
'        console.log(">> starting sum SAL column")',
'        model.forEach(function(record, index, id) {',
'            var sal = parseFloat(record[salKey]),  // record[salKey] should be a little faster than using model.getValue in a loop',
'                meta = model.getRecordMetadata(id);',
'',
'            if (!isNaN(sal) && !meta.deleted && !meta.agg) {',
'                total += sal;',
'            }',
'        });',
'        console.log(">> setting sum SAL column to " + total)',
'        $s("P38_INV_NET", total);',
'    }',
'',
'    //',
'    // This is the general pattern for subscribing to model notifications',
'    //',
'',
'    // need to do this here rather than in Execute when Page Loads so that the handler',
'    // is setup BEFORE the IG is initialized otherwise miss the first model created event',
'    $(function() {',
'        // the model gets released and created at various times such as when the report changes',
'        // listen for model created events so that we can subscribe to model notifications',
'        $("#inv_details").on("interactivegridviewmodelcreate", function(event, ui) {',
'            var sid,',
'                model = ui.model;',
'',
'            // note this is only done for the grid veiw. It could be done for',
'            // other views if desired. The imporant thing to realize is that each',
'            // view has its own model',
'            if ( ui.viewId === "grid" ) {',
'                sid = model.subscribe( {',
'                    onChange: function(type, change) {',
'                        console.log(">> model changed ", type, change);',
'                        if ( type === "set" ) {',
'                            // don''t bother to recalculate if other columns change',
'                            if (change.field === "ITEM_VAL" ) {',
'                                update( model );',
'                            }',
'                        } else if (type !== "move" && type !== "metaChange") {',
'                            // any other change except for move and metaChange affect the calculation',
'                            update( model );',
'                        }',
'                    },',
'                    progressView: $("#P38_INV_NET") // this will cause a spinner on this field',
'                } );',
'                // if not lazy loaded there is no notification for initial data so update',
'                update( model ); ',
'                // just in case fetch all the data. Model notifications will',
'                // cause calls to update so nothing to do in the callback function.',
'                // can remove if data will always be less than 50 records',
'                model.fetchAll(function() {});',
'            }',
'        });',
'',
'    });',
'',
'})(apex.jQuery);',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'ELWMO2005@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20231005160829'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39381899755800307830)
,p_plug_name=>unistr('\0641\0627\062A\0648\0631\0629 \0645\0634\062A\0631\064A\0627\062A')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(39371728561624209381)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39381921402006308021)
,p_plug_name=>unistr('\062A\0641\0627\0635\064A\0644 \0641\0627\062A\0648\0631\0629')
,p_region_name=>'inv_details'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39371727424569209381)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select INV_NO,',
'       INV_DATE,',
'       INV_TYPE,',
'       STORE_NO,',
'       DEALER_C,',
'       DEALER_TYPE,',
'       ITEM_C,',
'       QTY,',
'       PRICE,',
'       ITEM_VAL,',
'       UOM,',
'       UP_DATE,',
'       COMP_C,',
'       PAY_TYPE,',
'       BAL_AFTER,',
'       I_SEQ,',
'       CH_STORE_C,',
'       NOTES,',
'       EMP_ID,',
'       CLASS_C,',
'       SEO',
'  from INV_DETAIL',
' where INV_NO = :P38_INV_NO'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P38_INV_NO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381922571891308032)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381923110870308035)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_label=>'Actions'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_enable_hide=>true
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381923701071308039)
,p_name=>'INV_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INV_NO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P38_INV_NO'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381924314176308039)
,p_name=>'INV_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INV_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P38_INV_DATE'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381924884086308040)
,p_name=>'INV_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INV_TYPE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P38_INV_TYPE'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381925469583308041)
,p_name=>'STORE_NO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STORE_NO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P38_STORE_NO'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381926129312308041)
,p_name=>'DEALER_C'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DEALER_C'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P38_DEALER_C'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381926741647308041)
,p_name=>'DEALER_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DEALER_TYPE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381927306978308042)
,p_name=>'ITEM_C'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM_C'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>unistr('\0627\0644\0635\0646\0641')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'CENTER'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET_FILTER'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'2'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ITEM_N as d,',
'       ITEM_C as r',
'  from SANF',
'where CLASS_C=:CLASS_C',
' order by 1'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_cascade_parent_items=>'CLASS_C'
,p_ajax_items_to_submit=>'ITEM_C'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381927956110308042)
,p_name=>'QTY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTY'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('\0627\0644\0643\0645\064A\0629')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'CENTER'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381928540848308042)
,p_name=>'PRICE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRICE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('\0627\0644\0633\0639\0631')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'CENTER'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381929103121308043)
,p_name=>'ITEM_VAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ITEM_VAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('\0627\0644\0642\064A\0645\0629')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'CENTER'
,p_attribute_03=>'center'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381929751593308045)
,p_name=>'UOM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UOM'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381930359308308046)
,p_name=>'UP_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UP_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381930893061308047)
,p_name=>'COMP_C'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMP_C'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>160
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381931557001308047)
,p_name=>'PAY_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PAY_TYPE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>170
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381932154296308047)
,p_name=>'BAL_AFTER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BAL_AFTER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>180
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381932713695308048)
,p_name=>'I_SEQ'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'I_SEQ'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>190
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381933280136308048)
,p_name=>'CH_STORE_C'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CH_STORE_C'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>200
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381933873510308048)
,p_name=>'NOTES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NOTES'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>210
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381934473316308049)
,p_name=>'EMP_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMP_ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381935155034308049)
,p_name=>'CLASS_C'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CLASS_C'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>unistr('\0627\0644\0645\062C\0645\0648\0639\0629 \0627\0644\0635\0646\0641\064A\0629')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET_FILTER'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(39372163491765273891)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(39381935715331308049)
,p_name=>'SEO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>230
,p_attribute_01=>'Y'
,p_enable_filter=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(39381921919278308026)
,p_internal_uid=>28756926471262753
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(39381922341687308030)
,p_interactive_grid_id=>wwv_flow_imp.id(39381921919278308026)
,p_static_id=>'393514615'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(39381922390588308031)
,p_report_id=>wwv_flow_imp.id(39381922341687308030)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381923558795308035)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(39381923110870308035)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381924121336308039)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(39381923701071308039)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381924746510308040)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(39381924314176308039)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381925296673308041)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(39381924884086308040)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381925904677308041)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(39381925469583308041)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381926540266308041)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(39381926129312308041)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381927141546308042)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(39381926741647308041)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381927755703308042)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(39381927306978308042)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381928264196308042)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(39381927956110308042)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381928883817308043)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(39381928540848308042)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381929520335308045)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(39381929103121308043)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381930143976308045)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(39381929751593308045)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381930678820308046)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(39381930359308308046)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381931278830308047)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(39381930893061308047)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381931905041308047)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(39381931557001308047)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381932530250308047)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(39381932154296308047)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381933121223308048)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(39381932713695308048)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381933723264308048)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(39381933280136308048)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381934360234308049)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(39381933873510308048)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381934874314308049)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(39381934473316308049)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381935495520308049)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(39381935155034308049)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(39381935993258308050)
,p_view_id=>wwv_flow_imp.id(39381922390588308031)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(39381935715331308049)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367595597065737632)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\062D\0641\0638 \0627\0644\062A\063A\064A\0631\0627\062A')
,p_button_position=>'CHANGE'
,p_button_condition=>'P38_INV_NO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367596399155737633)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_button_name=>'GET_PREVIOUS_INV_NO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371783994102209437)
,p_button_image_alt=>'Previous'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P38_INV_NO_PREV'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-chevron-left'
,p_button_comment=>'This button is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367596799532737633)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_button_name=>'GET_NEXT_INV_NO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371783994102209437)
,p_button_image_alt=>'Next'
,p_button_position=>'CHANGE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P38_INV_NO_NEXT'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-chevron-right'
,p_button_comment=>'This button is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367594871747737632)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_image_alt=>unistr('\0627\0644\0631\062C\0648\0639')
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367596057541737633)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\062D\0641\0638')
,p_button_position=>'CREATE'
,p_button_condition=>'P38_INV_NO'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39367595200521737632)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_image_alt=>unistr('\062D\0630\0641 \0641\0627\062A\0648\0631\0629')
,p_button_position=>'DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P38_INV_NO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39364295084482003408)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_button_name=>'print'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371783994102209437)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Print'
,p_button_position=>'HELP'
,p_button_redirect_url=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:RP,38:P35_INV_NO:&P38_INV_NO.'
,p_button_condition=>'P38_INV_NO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-print'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(39367618812609737679)
,p_branch_name=>'stay_after'
,p_branch_action=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:RP:P38_INV_NO:&P38_INV_NO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(39367619272496737679)
,p_branch_name=>'direction_brachong'
,p_branch_action=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:RP:P38_INV_NO:&P38_INV_NO_NEXT.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(39367596799532737633)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(39367619682245737679)
,p_branch_name=>'direction_brachong'
,p_branch_action=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:RP:P38_INV_NO:&P38_INV_NO_PREV.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(39367596399155737633)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367597280728737634)
,p_name=>'P38_INV_NO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Inv No'
,p_source=>'INV_NO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367597616017737639)
,p_name=>'P38_INV_DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\062A\0627\0631\064A\062E \0627\0644\0641\0627\062A\0648\0631\0629')
,p_source=>'INV_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367598031211737639)
,p_name=>'P38_INV_TYPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_source=>'INV_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367598428052737640)
,p_name=>'P38_STORE_NO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\0627\0644\0645\062E\0632\0646')
,p_source=>'STORE_NO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'STORE_LIST'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367598866736737641)
,p_name=>'P38_DEALER_C'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\0627\0644\0645\0648\0631\062F')
,p_source=>'DEALER_C'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'SUPPLIERS_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DEALER_N as d,',
'       DEALER_C as r',
'  from DEALERS',
'where DEALER_TYPE =1	',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367599256350737641)
,p_name=>'P38_DEALER_TYPE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_source=>'DEALER_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367599637246737641)
,p_name=>'P38_NOTE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\0645\0644\0627\062D\0638\0627\062A')
,p_source=>'NOTE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367600025982737641)
,p_name=>'P38_INV_DIS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_source=>'INV_DIS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367600435666737642)
,p_name=>'P38_INV_NET'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('\0627\062C\0645\0627\0644\064A \0627\0644\0641\0627\062A\0648\0631\0629')
,p_source=>'INV_NET'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'center'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367600863878737642)
,p_name=>'P38_UP_DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_source=>'UP_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367601235615737642)
,p_name=>'P38_USER_C'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_source=>'USER_C'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367601665943737642)
,p_name=>'P38_COMP_C'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_source=>'COMP_C'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367602004962737643)
,p_name=>'P38_PAY_TYPE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_source=>'PAY_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367602414281737643)
,p_name=>'P38_CH_STORE_C'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_source=>'CH_STORE_C'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367602814887737643)
,p_name=>'P38_EMP_ID'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_use_cache_before_default=>'NO'
,p_source=>'EMP_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367603247345737643)
,p_name=>'P38_INV_NO_NEXT'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_prompt=>'P38_INV_NO_NEXT'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_item_comment=>'This item is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367603598279737643)
,p_name=>'P38_INV_NO_PREV'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_prompt=>'P38_INV_NO_PREV'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_item_comment=>'This item is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39367604064011737644)
,p_name=>'P38_INV_NO_COUNT'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(39381899755800307830)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cSize=>30
,p_tag_attributes=>'class="fielddata"'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
,p_item_comment=>'This item is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39367616989851737674)
,p_name=>'get_item_price'
,p_event_sequence=>10
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(39381921402006308021)
,p_triggering_element=>'ITEM_C'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39367617408082737676)
,p_event_id=>wwv_flow_imp.id(39367616989851737674)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'PRICE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SANF.BUY_PRICE as BUY_PRICE ',
' from SANF SANF',
'where ITEM_C =:ITEM_C '))
,p_attribute_07=>'ITEM_C'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39367617886054737676)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(39381921402006308021)
,p_triggering_element=>'QTY,PRICE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39367618354601737677)
,p_event_id=>wwv_flow_imp.id(39367617886054737676)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'ITEM_VAL'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':qty * :price'
,p_attribute_07=>'QTY,PRICE'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367615379648737673)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from INVOICE'
,p_attribute_02=>'INVOICE'
,p_attribute_03=>'P38_INV_NO'
,p_attribute_04=>'INV_NO'
,p_internal_uid=>39367615379648737673
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367616500430737673)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_PAGINATION'
,p_process_name=>'Get Next or Previous Primary Key Value'
,p_attribute_02=>'INVOICE'
,p_attribute_03=>'P38_INV_NO'
,p_attribute_04=>'INV_NO'
,p_attribute_07=>'INV_NO'
,p_attribute_09=>'P38_INV_NO_NEXT'
,p_attribute_10=>'P38_INV_NO_PREV'
,p_attribute_13=>'P38_INV_NO_COUNT'
,p_internal_uid=>39367616500430737673
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367615756255737673)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of INVOICE'
,p_attribute_02=>'INVOICE'
,p_attribute_03=>'P38_INV_NO'
,p_attribute_04=>'INV_NO'
,p_attribute_09=>'P38_INV_NO'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>39367615756255737673
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367614501328737670)
,p_process_sequence=>35
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(39381921402006308021)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('\062A\0641\0627\0635\064A\0644 \0641\0627\062A\0648\0631\0629 - Save Interactive Grid Data')
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    case :APEX$ROW_STATUS',
'    when ''C'' then',
'        insert into INV_DETAIL ( seo, inv_no, inv_date,inv_type,class_c,item_c,qty,price,item_val,store_no,dealer_c ,dealer_type)',
'        values ( :seo, :P38_INV_NO,:P38_INV_DATE,:P38_INV_TYPE,:class_c,:item_c,:qty,:price,:item_val,:P38_STORE_NO,:P38_DEALER_C,:P38_DEALER_type )',
'        returning seo into :seo ;',
'    when ''U'' then',
'        update INV_DETAIL',
'           set  inv_date= :ENAME,',
'               class_c= :class_c,',
'              item_c=:item_c,',
'             qty=:qty,',
'             price=:price,',
'            item_val=:item_val,',
'            store_no=:P38_STORE_NO,',
'            DEALER_C=:P38_DEALER_C,',
'            DEALER_type=:P38_DEALER_type',
'         where seo = :seo ;',
'    when ''D'' then',
'        delete INV_DETAIL',
'         where seo = :seo ;',
'    end case;',
'end;',
''))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>39367614501328737670
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367614923208737671)
,p_process_sequence=>45
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'update|_total'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update INVOICE',
'set INV_NET=(select sum(ITEM_VAL) from INV_DETAIL',
'where INV_NO=:P38_INV_NO)',
'where INV_NO=:P38_INV_NO;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>39367614923208737671
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39367616170111737673)
,p_process_sequence=>55
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(39367595200521737632)
,p_internal_uid=>39367616170111737673
);
wwv_flow_imp.component_end;
end;
/
