prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page(
 p_id=>23
,p_name=>unistr('\0645\0631\062A\062C\0639\0627\062A \0627\0644\0645\0628\064A\0639\0627\062A')
,p_step_title=>unistr('\0645\0631\062A\062C\0639\0627\062A \0627\0644\0645\0628\064A\0639\0627\062A')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20230131101701'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39389742968866243378)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39371727424569209381)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'INVOICE'
,p_query_where=>'INV_TYPE=2'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(39389743388559243378)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP:P24_INV_NO:\#INV_NO#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'ADMIN'
,p_internal_uid=>25868778443320894
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372623360501538826)
,p_db_column_name=>'INV_NO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>unistr('\0631\0642\0645 \0627\0644\0641\0627\062A\0648\0631\0629')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372623739154538826)
,p_db_column_name=>'INV_DATE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>unistr('\062A\0627\0631\064A\062E \0641\0627\062A\0648\0631\0629')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'YYYY-MM-DD'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372624200772538827)
,p_db_column_name=>'INV_TYPE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Inv Type'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372624609171538827)
,p_db_column_name=>'STORE_NO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('\0627\0644\0645\062E\0632\0646')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(39372169753987951385)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372624941421538827)
,p_db_column_name=>'DEALER_C'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('\0627\0644\0639\0645\064A\0644')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(39372614323487027794)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372625408617538827)
,p_db_column_name=>'DEALER_TYPE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Dealer Type'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372625710910538827)
,p_db_column_name=>'NOTE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>unistr('\0645\0644\0627\062D\0638\0627\062A')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372626169321538828)
,p_db_column_name=>'INV_DIS'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>unistr('\062E\0635\0645 \0627\0644\0641\0627\062A\0648\0631\0629')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372626570207538828)
,p_db_column_name=>'INV_NET'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>unistr('\0635\0627\0641\064A \0627\0644\0641\0627\062A\0648\0631\0629')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372627008193538828)
,p_db_column_name=>'UP_DATE'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Up Date'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372627355269538828)
,p_db_column_name=>'USER_C'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'User C'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372627764052538830)
,p_db_column_name=>'COMP_C'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Comp C'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372628161305538830)
,p_db_column_name=>'PAY_TYPE'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Pay Type'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372628536949538830)
,p_db_column_name=>'CH_STORE_C'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Ch Store C'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39372628996338538830)
,p_db_column_name=>'EMP_ID'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Emp Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(39389759271754471650)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'87547'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'INV_NO:INV_DATE:INV_TYPE:STORE_NO:DEALER_C:DEALER_TYPE:NOTE:INV_DIS:INV_NET:UP_DATE:USER_C:COMP_C:PAY_TYPE:CH_STORE_C:EMP_ID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39372629801357538831)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(39389742968866243378)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\062C\062F\064A\062F')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:24::'
);
wwv_flow_imp.component_end;
end;
/
