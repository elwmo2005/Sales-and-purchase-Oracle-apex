prompt --application/pages/page_00028
begin
--   Manifest
--     PAGE: 00028
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>33918883513805301269
,p_default_application_id=>243368
,p_default_id_offset=>39351450985745904405
,p_default_owner=>'WKSP_TEST1EXAM'
);
wwv_flow_imp_page.create_page(
 p_id=>28
,p_name=>unistr('\062A\0639\062F\064A\0644 \062D\0631\0643\0629 \0627\0644\062E\0632\064A\0646\0629 \0645\0639 \0627\0644\0639\0645\0644\0627\0621')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\062A\0639\062F\064A\0644 \062D\0631\0643\0629 \0627\0644\062E\0632\064A\0646\0629 \0645\0639 \0627\0644\0639\0645\0644\0627\0621')
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script>',
'function convertNumberToArabicWords() {',
'  const number = parseInt($(''#P28_AMOUNT_V'').val(), 10);',
unistr('  const arabicOnes = ["\0635\0641\0631", "\0648\0627\062D\062F", "\0627\062B\0646\0627\0646", "\062B\0644\0627\062B\0629", "\0623\0631\0628\0639\0629", "\062E\0645\0633\0629", "\0633\062A\0629", "\0633\0628\0639\0629", "\062B\0645\0627\0646\064A\0629", "\062A\0633\0639\0629", "\0639\0634\0631\0629", "\0623\062D\062F \0639\0634\0631", "\0627\062B\0646\0627 \0639\0634\0631", "\062B\0644\0627\062B\0629 \0639\0634\0631", "\0623\0631\0628\0639\0629 \0639\0634\0631", "\062E\0645\0633\0629 \0639\0634\0631", "\0633\062A\0629 \0639\0634\0631", "\0633\0628\0639\0629 \0639\0634\0631", "\062B\0645\0627\0646\064A\0629 \0639\0634\0631", "\062A\0633\0639\0629 \0639\0634\0631"];'),
unistr('  const arabicTens = ["\0639\0634\0631\0648\0646", "\062B\0644\0627\062B\0648\0646", "\0623\0631\0628\0639\0648\0646", "\062E\0645\0633\0648\0646", "\0633\062A\0648\0646", "\0633\0628\0639\0648\0646", "\062B\0645\0627\0646\0648\0646", "\062A\0633\0639\0648\0646"];'),
unistr('  const arabicHundreds = ["", "\0645\0627\0626\0629", "\0645\0626\062A\0627\0646", "\062B\0644\0627\062B\0645\0627\0626\0629", "\0623\0631\0628\0639\0645\0627\0626\0629", "\062E\0645\0633\0645\0627\0626\0629", "\0633\062A\0645\0627\0626\0629", "\0633\0628\0639\0645\0627\0626\0629", "\062B\0645\0627\0646\0645\0627\0626\0629", "\062A\0633\0639\0645\0627\0626\0629"];'),
unistr('  const arabicBigNumbers = ["", "\0627\0644\0641", "\0645\0644\064A\0648\0646", "\0645\0644\064A\0627\0631", "\062A\0631\064A\0644\064A\0648\0646", "\062A\0631\064A\0644\064A\0627\0631"];'),
'  ',
'  let index = 0;',
'  let currentNumber = number;',
'  let result = "";',
'  ',
'  while (currentNumber > 0) {',
'    if (currentNumber % 1000 !== 0) {',
'      result = convertLessThanOneThousand(currentNumber % 1000) + " " + arabicBigNumbers[index] + " " + result;',
'    }',
'    currentNumber = Math.floor(currentNumber / 1000);',
'    index++;',
'  }',
'  ',
'  $(''#P28_KKK'').val(result.trim());',
'  ',
'  function convertLessThanOneThousand(number) {',
'    if (number < 20) {',
'      return arabicOnes[number];',
'    } else if (number < 100) {',
unistr('      return arabicTens[Math.floor(number / 10) - 2] + (number % 10 === 0 ? "" : " \0648 " + arabicOnes[number % 10]);'),
'    } else if (number < 1000) {',
unistr('      return arabicHundreds[Math.floor(number / 100)] + (number % 100 === 0 ? "" : " \0648 " + convertLessThanOneThousand(number % 100));'),
'    }',
'  }',
'}',
'    ',
'',
'      ',
'',
'',
'',
'',
'',
'',
'</script>'))
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'ELWMO2005@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20230715151142'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39381652880900083627)
,p_plug_name=>unistr('\062A\0639\062F\064A\0644 \062D\0631\0643\0629 \0627\0644\062E\0632\064A\0646\0629 \0645\0639 \0627\0644\0639\0645\0644\0627\0621')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39371703396522209369)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'BOX'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39381665738943083660)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(39371704373694209369)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39372839188216840934)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(39381665738943083660)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_image_alt=>unistr('\0627\0644\063A\0627\0621 \0627\0644\0627\0645\0631')
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39372839591885840935)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(39381665738943083660)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_image_alt=>unistr('\062D\0630\0641')
,p_button_position=>'DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P28_BOX_SEQ'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39372839926058840935)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(39381665738943083660)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\062D\0641\0638 \0627\0644\062A\063A\064A\0631\0627\062A')
,p_button_position=>'NEXT'
,p_button_condition=>'P28_BOX_SEQ'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39372840315553840935)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(39381665738943083660)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(39371784657506209438)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('\062C\062F\064A\062F')
,p_button_position=>'NEXT'
,p_button_condition=>'P28_BOX_SEQ'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372841086145840936)
,p_name=>'P28_BOX_SEQ'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Box Seq'
,p_source=>'BOX_SEQ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(39371783532288209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372841431842840937)
,p_name=>'P28_BOX_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_prompt=>unistr('\062A\0627\0631\064A\062E \0627\0644\0639\0645\0644\064A\0629')
,p_format_mask=>'YYYY-MM-DD'
,p_source=>'BOX_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(39371783397998209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372841893437840938)
,p_name=>'P28_BOX_TYPE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_default=>'1'
,p_prompt=>unistr('\0637\0628\064A\0639\0629 \0627\0644\0639\0645\0644\064A\0629')
,p_source=>'BOX_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC:\062A\062D\0635\064A\0644;1,\0635\0631\0641;2')
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(39371783397998209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372842212222840938)
,p_name=>'P28_DEALER_C'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_prompt=>unistr('\0627\0644\0639\0645\064A\0644')
,p_source=>'DEALER_C'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CUSTOMERS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DEALER_N as d,',
'       DEALER_C as r',
'  from DEALERS',
'where DEALER_TYPE =2	',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('-----\0627\0644\0639\0645\064A\0644------')
,p_cHeight=>1
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(39371783397998209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372842657904840939)
,p_name=>'P28_PAY_TYPE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_default=>'1'
,p_prompt=>unistr('\0637\0631\064A\0642\0629 \0627\0644\062F\0641\0639')
,p_source=>'PAY_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>unistr('STATIC:\0646\0642\062F;1,\0634\064A\0643;2')
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_grid_column=>6
,p_field_template=>wwv_flow_imp.id(39371783397998209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372843052712840939)
,p_name=>'P28_AMOUNT_V'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_prompt=>unistr('\0627\0644\0645\0628\0644\063A')
,p_source=>'AMOUNT_V'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(39371783397998209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'center'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372843465438840939)
,p_name=>'P28_KKK'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_post_element_text=>unistr('\062C\0640\0646\064A\0647\0627')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>300
,p_tag_attributes=>'readonly="readonly"'
,p_begin_on_new_line=>'N'
,p_colspan=>7
,p_field_template=>wwv_flow_imp.id(39371783397998209436)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372843873998840939)
,p_name=>'P28_NOTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_prompt=>unistr('\0645\0644\0627\062D\0638\0627\062A')
,p_source=>'NOTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_colspan=>8
,p_field_template=>wwv_flow_imp.id(39371783397998209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372844276723840939)
,p_name=>'P28_TRANS_C'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_default=>'2'
,p_source=>'TRANS_C'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372844706500840940)
,p_name=>'P28_UP_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_source=>'UP_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372845022926840940)
,p_name=>'P28_COMP_C'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_source=>'COMP_C'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372845474630840940)
,p_name=>'P28_USER_C'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_source=>'USER_C'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372845830842840940)
,p_name=>'P28_DEALER_TYPE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_default=>'2'
,p_source=>'DEALER_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372846261105840940)
,p_name=>'P28_BANK_C'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_prompt=>unistr('\0627\0644\0628\0646\0643')
,p_source=>'BANK_C'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(39371783397998209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372846630714840941)
,p_name=>'P28_CHECK_NO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_prompt=>unistr('\0631\0642\0645 \0627\0644\0634\064A\0643')
,p_source=>'CHECK_NO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(39371783397998209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372847031053840943)
,p_name=>'P28_EMP_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_source=>'EMP_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372847482054840943)
,p_name=>'P28_TRANS_SEQ'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_source=>'TRANS_SEQ'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39372847880558840945)
,p_name=>'P28_CHECK_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_item_source_plug_id=>wwv_flow_imp.id(39381652880900083627)
,p_prompt=>unistr('\062A\0627\0631\064A\062E \0627\0633\062A\062D\0642\0627\0642 ')
,p_source=>'CHECK_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(39371783397998209436)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39372854533103840949)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(39372839188216840934)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39372855040882840949)
,p_event_id=>wwv_flow_imp.id(39372854533103840949)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39372855451201840949)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P28_AMOUNT_V'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39372855999119840949)
,p_event_id=>wwv_flow_imp.id(39372855451201840949)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P28_KKK'
,p_attribute_01=>'convertNumberToArabicWords();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39372856462349840949)
,p_event_id=>wwv_flow_imp.id(39372855451201840949)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P28_KKK'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39372848614526840945)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(39381652880900083627)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form \062A\0639\062F\064A\0644 \062D\0631\0643\0629 \0627\0644\062E\0632\064A\0646\0629 \0645\0639 \0645\0648\0631\062F\064A\0646')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>39372848614526840945
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39372854119074840948)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>39372854119074840948
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(39372848242938840945)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(39381652880900083627)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form \062A\0639\062F\064A\0644 \062D\0631\0643\0629 \0627\0644\062E\0632\064A\0646\0629 \0645\0639 \0645\0648\0631\062F\064A\0646')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>39372848242938840945
);
wwv_flow_imp.component_end;
end;
/
